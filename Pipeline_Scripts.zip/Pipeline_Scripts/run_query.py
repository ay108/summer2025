from s2_query.s2_search import query_nearest_neighbors

lat = 40.7128  # Replace with your query lat
lon = -74.0060 # Replace with your query lon

results = query_nearest_neighbors(lat, lon, k=10)

for i, r in enumerate(results, 1):
    print(f"{i}. {r['location_id']} - {r['name']} at ({r['lat']}, {r['lon']})")
