# -*- coding: utf-8 -*-
"""

Portfolio Analysis Pipeline
Created on Mon Jul 21 15:38:04 2025

@author: Ashley.Yang

This script provides a complete pipeline for analyzing portfolio data including:
- EP Portfolio aggregation for GR and GU loss types
- Stats Portfolio aggregation for GR and GU loss types  
- Threshold analysis
- Plot generation with legends
- Excel output with embedded charts

"""
#%%
import pandas as pd
import matplotlib.pyplot as plt
import os
import re
import io
from matplotlib.cm import get_cmap
from matplotlib.colors import to_hex
#%%
def ep_port_aggregating_files_to_expected(results_base_path, loss_type):
    """
    Aggregates EP portfolio files from Results directory.
    Expected folder and sample folders are all at the same level in Results directory.
    
    Args:
        results_base_path: Path to Results directory containing all folders
        loss_type: "GU" or "GR"
    
    Returns:
        DataFrame with aggregated EP portfolio data
    """
    print(f"Processing EP Portfolio data for Loss Type: {loss_type}")
    print(f"Results Directory: {results_base_path}")
    
    df = pd.DataFrame()
    sample_sizes = []
    
    # Validate loss_type
    if loss_type not in ['GU', 'GR']:
        print(f"Warning: Unexpected loss_type '{loss_type}'. Expected 'GU' or 'GR'")
        return pd.DataFrame()
    
    if not os.path.exists(results_base_path):
        print(f"Results directory not found: {results_base_path}")
        return pd.DataFrame()
    
    result_folders = [d for d in os.listdir(results_base_path) 
                     if os.path.isdir(os.path.join(results_base_path, d))]
    
    print(f"Found {len(result_folders)} folders")
    
    # Step 1: Find and load the Expected folder
    expected_found = False
    for folder_name in result_folders:
        if "Expected" in folder_name:
            folder_path = os.path.join(results_base_path, folder_name)
            expected_file_path = os.path.join(folder_path, "EP", "Portfolio", loss_type, "EP100.parquet")
            
            if os.path.exists(expected_file_path):
                df = pd.read_parquet(expected_file_path)
                df['Expected'] = df['Loss']
                df['LossType'] = loss_type
                expected_found = True
                print(f"Loaded Expected data from folder: {folder_name}")
                break
    
    if not expected_found:
        print(f"No Expected folder found for {loss_type}")
        return pd.DataFrame()
    
    # Step 2: Process all sample folders
    processed_files = 0
    for folder_name in result_folders:
        if "Expected" not in folder_name:  # Skip the Expected folder
            folder_path = os.path.join(results_base_path, folder_name)
            sample_file_path = os.path.join(folder_path, "EP", "Portfolio", loss_type, "EP100.parquet")
            
            if os.path.exists(sample_file_path):
                try:
                    df_temp = pd.read_parquet(sample_file_path)
                    
                    # Extract sample size from folder name
                    sample_size = None
                    match = re.search(r'_(\d+)$', folder_name)
                    if match:
                        sample_size = int(match.group(1))
                    else:
                        # Fallback: use processed count + 1
                        sample_size = processed_files + 1
                    
                    # Add sample column
                    column_name = f'S{sample_size}'
                    df[column_name] = df_temp['Loss']
                    sample_sizes.append(sample_size)
                    processed_files += 1
                    print(f"Added {loss_type} sample from {folder_name}: {column_name}")
                    
                except Exception as e:
                    print(f"Error processing {folder_name}: {str(e)}")
                    continue
    
    sample_sizes.sort()
    print(f"Processed {processed_files} sample folders")
    print(f"Sample sizes: {sample_sizes}")
    
    for sample_size in sample_sizes:
        s_col = f'S{sample_size}'
        if s_col in df.columns and 'Expected' in df.columns:
            df[f'{s_col}vsExpected'] = (df[s_col] - df['Expected']) / df['Expected'] * 100

    # Reorder columns
    base_cols = [col for col in df.columns if not col.startswith('S') or col == 'S32vsExpected']
    s_cols = sorted([col for col in df.columns if col.startswith('S') and 'vs' not in col and col[1:].isdigit()],
                    key=lambda x: int(x[1:]))
    vs_cols = sorted([col for col in df.columns if 'vsS32' in col and col[1:col.find('v')].isdigit()],
                     key=lambda x: int(x[1:x.find('v')]))

    if 'S32vsExpected' in base_cols:
        base_cols.remove('S32vsExpected')
        
    print(df.columns)

    new_order = base_cols + s_cols + vs_cols + ['S32vsExpected']
    df = df[new_order]

    # Filter to only OEP data
    if 'EPType' in df.columns:
        df = df[df['EPType'] == 'OEP']

    return df
    print(f"Results Directory: {results_base_path}")

#%%
def ep_port_aggregating_files(results_base_path, loss_type):
    """
    Aggregates EP portfolio files from Results directory.
    Expected folder and sample folders are all at the same level in Results directory.
    
    Args:
        results_base_path: Path to Results directory containing all folders
        loss_type: "GU" or "GR"
    
    Returns:
        DataFrame with aggregated EP portfolio data
    """
    print(f"Processing EP Portfolio data for Loss Type: {loss_type}")
    print(f"Results Directory: {results_base_path}")
    
    df = pd.DataFrame()
    sample_sizes = []
    
    # Validate loss_type
    if loss_type not in ['GU', 'GR']:
        print(f"Warning: Unexpected loss_type '{loss_type}'. Expected 'GU' or 'GR'")
        return pd.DataFrame()
    
    if not os.path.exists(results_base_path):
        print(f"Results directory not found: {results_base_path}")
        return pd.DataFrame()
    
    result_folders = [d for d in os.listdir(results_base_path) 
                     if os.path.isdir(os.path.join(results_base_path, d))]
    
    print(f"Found {len(result_folders)} folders")
    
    # Step 1: Find and load the Expected folder
    expected_found = False
    for folder_name in result_folders:
        if "Expected" in folder_name:
            folder_path = os.path.join(results_base_path, folder_name)
            expected_file_path = os.path.join(folder_path, "EP", "Portfolio", loss_type, "EP100.parquet")
            
            if os.path.exists(expected_file_path):
                df = pd.read_parquet(expected_file_path)
                df['Expected'] = df['Loss']
                df['LossType'] = loss_type
                expected_found = True
                print(f"Loaded Expected data from folder: {folder_name}")
                break
    
    if not expected_found:
        print(f"No Expected folder found for {loss_type}")
        return pd.DataFrame()
    
    # Step 2: Process all sample folders
    processed_files = 0
    for folder_name in result_folders:
        if "Expected" not in folder_name:  # Skip the Expected folder
            folder_path = os.path.join(results_base_path, folder_name)
            sample_file_path = os.path.join(folder_path, "EP", "Portfolio", loss_type, "EP100.parquet")
            
            if os.path.exists(sample_file_path):
                try:
                    df_temp = pd.read_parquet(sample_file_path)
                    
                    # Extract sample size from folder name
                    sample_size = None
                    match = re.search(r'_(\d+)$', folder_name)
                    if match:
                        sample_size = int(match.group(1))
                    else:
                        # Fallback: use processed count + 1
                        sample_size = processed_files + 1
                    
                    # Add sample column
                    column_name = f'S{sample_size}'
                    df[column_name] = df_temp['Loss']
                    sample_sizes.append(sample_size)
                    processed_files += 1
                    print(f"Added {loss_type} sample from {folder_name}: {column_name}")
                    
                except Exception as e:
                    print(f"Error processing {folder_name}: {str(e)}")
                    continue
    
    sample_sizes.sort()
    print(f"Processed {processed_files} sample folders")
    print(f"Sample sizes: {sample_sizes}")
    
    # Calculate differences vs S32
    for sample_size in sample_sizes:
        s_col = f'S{sample_size}'
        if sample_size != 32 and s_col in df.columns and 'S32' in df.columns:
            df[f'{s_col}vsS32'] = (df[s_col] - df['S32']) / df['S32'] * 100

    # Calculate all sample sizes vs Expected
    for sample_size in sample_sizes:
        s_col = f'S{sample_size}'
        if s_col in df.columns and 'Expected' in df.columns:
            df[f'{s_col}vsExpected'] = (df[s_col] - df['Expected']) / df['Expected'] * 100

    # Reorder columns
    base_cols = [col for col in df.columns if not col.startswith('S')]
    s_cols = sorted([col for col in df.columns if col.startswith('S') and 'vs' not in col and col[1:].isdigit()],
                    key=lambda x: int(x[1:]))
    vs_s32_cols = sorted([col for col in df.columns if 'vsS32' in col and col[1:col.find('v')].isdigit()],
                         key=lambda x: int(x[1:x.find('v')]))
    vs_expected_cols = sorted([col for col in df.columns if 'vsExpected' in col and col != 'S32vsExpected' and col[1:col.find('v')].isdigit()],
                              key=lambda x: int(x[1:x.find('v')]))
        
    print(df.columns)

    new_order = base_cols + s_cols + vs_s32_cols + vs_expected_cols
    if 'S32vsExpected' in df.columns:
        new_order += ['S32vsExpected']
    df = df[new_order]

    # Filter to only OEP data
    if 'EPType' in df.columns:
        df = df[df['EPType'] == 'OEP']

    return df
    print(f"Results Directory: {results_base_path}")
    
#%%
def stat_port_aggregating_files(results_base_path, loss_type):
    """
    Aggregates Stats portfolio files from Results directory.
    Expected folder and sample folders are all at the same level in Results directory.
    Uses AAL (Average Annual Loss) instead of Loss.
    
    Args:
        results_base_path: Path to Results directory containing all folders
        loss_type: "GU" or "GR"
    
    Returns:
        DataFrame with aggregated Stats portfolio data
    """
    print(f"Processing Stats Portfolio data for Loss Type: {loss_type}")
    print(f"Results Directory: {results_base_path}")
    
    df = pd.DataFrame()
    sample_sizes = []
    
    # Validate loss_type
    if loss_type not in ['GU', 'GR']:
        print(f"Warning: Unexpected loss_type '{loss_type}'. Expected 'GU' or 'GR'")
        return pd.DataFrame()
    
    if not os.path.exists(results_base_path):
        print(f"Results directory not found: {results_base_path}")
        return pd.DataFrame()
    
    result_folders = [d for d in os.listdir(results_base_path) 
                     if os.path.isdir(os.path.join(results_base_path, d))]
    
    print(f"Found {len(result_folders)} folders")
    
    # Step 1: Find and load the Expected folder
    expected_found = False
    for folder_name in result_folders:
        if "Expected" in folder_name:
            folder_path = os.path.join(results_base_path, folder_name)
            expected_file_path = os.path.join(folder_path, "Stats", "Portfolio", loss_type, "Stats100.parquet")
            
            if os.path.exists(expected_file_path):
                df = pd.read_parquet(expected_file_path)
                df['Expected'] = df['AAL']  # Use AAL for stats instead of Loss
                df['LossType'] = loss_type
                expected_found = True
                print(f"Loaded Expected data from folder: {folder_name}")
                break
    
    if not expected_found:
        print(f"No Expected folder found for {loss_type}")
        return pd.DataFrame()
    
    # Step 2: Process all sample folders
    processed_files = 0
    for folder_name in result_folders:
        if "Expected" not in folder_name:  # Skip the Expected folder
            folder_path = os.path.join(results_base_path, folder_name)
            sample_file_path = os.path.join(folder_path, "Stats", "Portfolio", loss_type, "Stats100.parquet")
            
            if os.path.exists(sample_file_path):
                try:
                    df_temp = pd.read_parquet(sample_file_path)
                    
                    # Extract sample size from folder name
                    sample_size = None
                    folder_name = folder_name.strip()

                    match = re.search(r'_(\d+)$', folder_name)
                    if match:
                        sample_size = int(match.group(1))
                    else:
                        # Fallback: use processed count + 1
                        sample_size = processed_files + 1
                    
                    # Add sample column using AAL
                    column_name = f'S{sample_size}'
                    df[column_name] = df_temp['AAL']  # Use AAL for stats instead of Loss
                    sample_sizes.append(sample_size)
                    processed_files += 1
                    print(f"Added {loss_type} sample from {folder_name}: {column_name}")
                    
                except Exception as e:
                    print(f"Error processing {folder_name}: {str(e)}")
                    continue
    
    sample_sizes.sort()
    print(f"Processed {processed_files} sample folders")
    print(f"Sample sizes: {sample_sizes}")
    
    # Calculate differences vs S32
    for sample_size in sample_sizes:
        s_col = f'S{sample_size}'
        if sample_size != 32 and s_col in df.columns and 'S32' in df.columns:
            df[f'{s_col}vsS32'] = (df[s_col] - df['S32']) / df['S32'] * 100

    # Calculate S32 vs Expected (this is the key comparison)
    if 'S32' in df.columns and 'Expected' in df.columns:
        df['S32vsExpected'] = (df['S32'] - df['Expected']) / df['Expected'] * 100

    # Reorder columns
    base_cols = [col for col in df.columns if not col.startswith('S') or col == 'S32vsExpected']
    s_cols = sorted([col for col in df.columns if col.startswith('S') and 'vs' not in col and col[1:].isdigit()],
                    key=lambda x: int(x[1:]))
    vs_cols = sorted([col for col in df.columns if 'vsS32' in col and col[1:col.find('v')].isdigit()],
                     key=lambda x: int(x[1:x.find('v')]))

    if 'S32vsExpected' in base_cols:
        base_cols.remove('S32vsExpected')

    new_order = base_cols + s_cols + vs_cols
    if 'S32vsExpected' in df.columns:
        new_order += ['S32vsExpected']
    df = df[new_order]

    return df
#%%
def stat_risk_aggregating(results_base_path, loss_type):
    

    print(f"Processing Stats Risk data for Loss Type: {loss_type}")
    print(f"Results Directory: {results_base_path}")
    
    df = pd.DataFrame()
    sample_sizes = []
    
    # Validate loss_type
    if loss_type not in ['GU', 'GR']:
        print(f"Warning: Unexpected loss_type '{loss_type}'. Expected 'GU' or 'GR'")
        return pd.DataFrame()
    
    if not os.path.exists(results_base_path):
        print(f"Results directory not found: {results_base_path}")
        return pd.DataFrame()
    
    result_folders = [d for d in os.listdir(results_base_path) 
                     if os.path.isdir(os.path.join(results_base_path, d))]
    
    print(f"Found {len(result_folders)} folders")
    
    # Step 1: Find and load the Expected folder
    expected_found = False
    for folder_name in result_folders:
        if "Expected" in folder_name:
            folder_path = os.path.join(results_base_path, folder_name)
            expected_file_path = os.path.join(folder_path, "Stats", "Risk", loss_type, "Stats100.parquet")
            
            if os.path.exists(expected_file_path):
                df = pd.read_parquet(expected_file_path)
                df['Expected'] = df['AAL']  # Use AAL for stats instead of Loss
                df['LossType'] = loss_type
                expected_found = True
                print(f"Loaded Expected data from folder: {folder_name}")
                break
    
    if not expected_found:
        print(f"No Expected folder found for {loss_type}")
        return pd.DataFrame()
    
    # Step 2: Process all sample folders
    processed_files = 0
    for folder_name in result_folders:
        if "Expected" not in folder_name:  # Skip the Expected folder
            folder_path = os.path.join(results_base_path, folder_name)
            sample_file_path = os.path.join(folder_path, "Stats", "Risk", loss_type, "Stats100.parquet")
            
            if os.path.exists(sample_file_path):
                try:
                    sample_size = None
                    match = re.search(r'_(\d+)$', folder_name)
                    if match:
                        sample_size = int(match.group(1))
                    else:
                        print("Sample size not found")
                    
                    df_temp = pd.read_parquet(sample_file_path)
                    df_temp = df_temp[['LocationId', 'AAL']].rename(columns={'AAL': f'S{sample_size}'})
                    df = df.merge(df_temp, on='LocationId', how='inner')
                    sample_sizes.append(sample_size)
                    processed_files += 1
                    print(f"Added {loss_type} sample from {folder_name}: S{sample_size}")
                    
                except Exception as e:
                    print(f"Error processing {folder_name}: {str(e)}")
                    continue
    
    sample_sizes.sort()
    print(f"Processed {processed_files} sample folders")
    print(f"Sample sizes: {sample_sizes}")
    
    # Calculate differences vs S32
    for sample_size in sample_sizes:
        s_col = f'S{sample_size}'
        if sample_size != 32 and s_col in df.columns and 'S32' in df.columns:
            df[f'{s_col}vsS32'] = (df[s_col] - df['S32']) / df['S32'] * 100

    # Calculate S32 vs Expected (this is the key comparison)
    if 'S32' in df.columns and 'Expected' in df.columns:
        df['S32vsExpected'] = (df['S32'] - df['Expected']) / df['Expected'] * 100

    # Reorder columns
    base_cols = [col for col in df.columns if not col.startswith('S') or col == 'S32vsExpected']
    s_cols = sorted([col for col in df.columns if col.startswith('S') and 'vs' not in col and col[1:].isdigit()],
                    key=lambda x: int(x[1:]))
    vs_cols = sorted([col for col in df.columns if 'vsS32' in col and col[1:col.find('v')].isdigit()],
                     key=lambda x: int(x[1:x.find('v')]))

    if 'S32vsExpected' in base_cols:
        base_cols.remove('S32vsExpected')

    new_order = base_cols + s_cols + vs_cols
    if 'S32vsExpected' in df.columns:
        new_order += ['S32vsExpected']
    df = df[new_order]

    return df
#%%
def calculate_thresholds(df, threshold_percentages=[1, 2], min_return_period=100, max_return_period=1000):
    """
    Calculate threshold analysis for convergence assessment.
    
    Args:
        df: DataFrame with sample columns (S1, S2, etc.) and S32vsExpected
        threshold_percentages: List of threshold percentages to analyze
        min_return_period: Minimum return period to analyze
        max_return_period: Maximum return period to analyze
    
    Returns:
        DataFrame with threshold analysis results
    """
    print("Calculating threshold analysis...")
    
    results = []
    
    # Get sample columns (excluding S32 and comparison columns)
    sample_cols = [col for col in df.columns if col.startswith('S') and 'vs' not in col and col != 'S32' and col[1:].isdigit()]
    sample_cols = sorted(sample_cols, key=lambda x: int(x[1:]))
    if 'S32vsExpected' not in df.columns:
        print("Warning: S32vsExpected column not found")
        return pd.DataFrame()
    
    # Filter dataframe to only include desired return period range
    df = df[(df['ReturnPeriod'] >= min_return_period) & (df['ReturnPeriod'] <= max_return_period)] #im only looking at return periods 100-1000 for analyzing which sample sizes are best 
    
    for threshold in threshold_percentages:
        for sample_col in sample_cols:
            if f'{sample_col}vsS32' in df.columns:
                # Count how many values are within threshold
                within_threshold = (abs(df[f'{sample_col}vsS32']) <= threshold).sum()
                total_count = len(df[f'{sample_col}vsS32'].dropna())
                percentage_within = (within_threshold / total_count * 100) if total_count > 0 else 0
                
                results.append({
                    'Sample_Size': int(sample_col[1:]),
                    'Threshold': "+/-" + str(threshold) + "%",
                    'Percentage_Within_Threshold': percentage_within, 
                    'within_threshold?': 'Yes' if percentage_within == 100 else 'No'
                })

    
    threshold_df = pd.DataFrame(results)
    print(f"Threshold analysis completed for {len(sample_cols)} samples and S32vsExpected")
    
    
    return threshold_df

#%%
def create_plots_with_legend(df, show_plots=True):
    """
    Create plots with legend information for Excel integration.
    
    Args:
        df: DataFrame with return period and sample comparison data
        show_plots: Boolean, whether to display plots on screen before saving
    
    Returns:
        Tuple of (plots_dict, legends_dict) where plots contains BytesIO buffers
        and legends contains color mapping for each plot
    """
    import numpy as np
    
    plots = {}
    legends = {}

    return_period_col = 'ReturnPeriod'
    vs_cols = [col for col in df.columns if col.endswith('vsS32') and col != 'S32vsExpected']
    
    if return_period_col not in df.columns:
        print("Warning: ReturnPeriod column not found")
        return plots, legends
    
    cmap = get_cmap('tab20')  # Use matplotlib tab20 color map

    # Plot 1: All sample % differences vs S32
    fig1, ax1 = plt.subplots(figsize=(10, 6))
    color_map = {}

    for i, col in enumerate(vs_cols):
        if col in df.columns:
            color = cmap(i % 20)
            hex_color = to_hex(color)
            color_map[col] = hex_color
            ax1.plot(df[return_period_col], df[col], label=col, color=color, linewidth=2)

    ax1.set_xlabel('Return Period')
    ax1.set_ylabel('% Difference from S32')
    ax1.set_title('All Sample % Differences vs S32')
    ax1.grid(True, alpha=0.3)
    ax1.set_xlim((0, df[return_period_col].max()))
    ax1.set_ylim((-10, 10))
    
    # Set custom axis ticks
    # Y-axis: every 0.2% from -10% to 10%
    y_ticks = np.arange(-10, 10, 2)
    ax1.set_yticks(y_ticks)
    
    # X-axis: every 100 years up to the max return period
    max_return_period = df[return_period_col].max()
    x_ticks = np.arange(0, max_return_period, 1000)
    ax1.set_xticks(x_ticks)
    
    ax1.legend(bbox_to_anchor=(1.05, 1), loc='upper left')

    # Show plot if requested
    if show_plots:
        plt.show()

    buf1 = io.BytesIO()
    fig1.tight_layout()
    fig1.savefig(buf1, format='png', dpi=300, bbox_inches='tight')
    buf1.seek(0)
    plots['all_samples'] = buf1
    legends['all_samples'] = color_map
    plt.close(fig1)


    # Plot 3: S32vsExpected if available
    if 'S32vsExpected' in df.columns:
        fig3, ax3 = plt.subplots(figsize=(8, 6))
        ax3.plot(df[return_period_col], df['S32vsExpected'], color='red', linewidth=2, label='S32vsExpected')
        ax3.set_xlabel('Return Period')
        ax3.set_ylabel('% Difference from Expected')
        ax3.set_title('S32 vs Expected % Difference')
        ax3.grid(True, alpha=0.3)
        ax3.legend()
        ax3.set_ylim((-100, 100))
        ax3.set_xlim((0, df[return_period_col].max()))
        
        # Set custom axis ticks for S32vsExpected plot
        ax3.set_yticks(y_ticks)  # Same y-axis ticks
        ax3.set_xticks(x_ticks)  # Same x-axis ticks

        # Show plot if requested
        if show_plots:
            plt.show()

        buf3 = io.BytesIO()
        fig3.tight_layout()
        fig3.savefig(buf3, format='png', dpi=300, bbox_inches='tight')
        buf3.seek(0)
        plots['s32_vs_expected'] = buf3
        legends['s32_vs_expected'] = {'S32vsExpected': '#FF0000'}  # red
        plt.close(fig3)

    return plots, legends

#%%
def insert_plots_with_legend(worksheet, plots, legends):
    """
    Insert plots and their legends into an Excel worksheet.
    
    Args:
        worksheet: xlsxwriter worksheet object
        plots: Dictionary of plot buffers
        legends: Dictionary of legend color mappings
    """
    row = 0
    for key, buf in plots.items():
        # Insert the plot image
        image_data = buf.read()
        worksheet.insert_image(row, 0, f"{key}.png", {'image_data': io.BytesIO(image_data)})

        # Insert the legend table beside it
        legend_map = legends.get(key, {})
        worksheet.write(row, 8, "Legend:")
        worksheet.write(row + 1, 8, "Line Name")
        worksheet.write(row + 1, 9, "Color (Hex)")

        for i, (line_name, hex_color) in enumerate(legend_map.items()):
            worksheet.write(row + 2 + i, 8, line_name)
            worksheet.write(row + 2 + i, 9, hex_color)

        row += 35  # Space between plots

#%%
def save_complete_analysis_to_excel(dataframes_dict, thresholds_dict=None, 
                                  output_path="analysis_output.xlsx", show_plots=True):
    """
    Save analysis results to Excel with data, plots, and legends.
    More flexible version that accepts a dictionary of dataframes.
    
    Args:
        dataframes_dict: Dictionary where keys are sheet names and values are DataFrames
                        If DataFrame contains 'Loss' column, plots will be created
                        If DataFrame contains 'AAL' column only, no plots will be created
        thresholds_dict: Optional dictionary of threshold analysis DataFrames
                        Keys should be sheet names, values should be threshold DataFrames
        output_path: Path for output Excel file
        show_plots: Boolean, whether to display plots on screen before saving to Excel
    """
    print(f"Saving complete analysis to: {output_path}")
    
    with pd.ExcelWriter(output_path, engine='xlsxwriter') as writer:
        workbook = writer.book
        
        # Write data sheets and create plots where appropriate
        for sheet_name, df in dataframes_dict.items():
            if df.empty:
                print(f"Skipping empty dataframe: {sheet_name}")
                continue
                
            # Write the data sheet
            df.to_excel(writer, sheet_name=sheet_name, index=False)
            print(f"Saved data sheet: {sheet_name}")
            
            # Determine if this dataframe should have plots
            should_create_plots = False
            if 'Loss' in df.columns and 'ReturnPeriod' in df.columns:
                # This looks like EP data - create plots
                should_create_plots = True
            elif 'AAL' in df.columns:
                # This looks like Stats data - no plots needed
                should_create_plots = False
                print(f"Skipping plots for {sheet_name} (contains AAL - Stats data)")
            
            # Create plots if appropriate
            if should_create_plots:
                try:
                    plots, legends = create_plots_with_legend(df, show_plots=show_plots)
                    if plots:
                        plot_sheet_name = f"{sheet_name}_Plots"
                        worksheet = workbook.add_worksheet(plot_sheet_name)
                        writer.sheets[plot_sheet_name] = worksheet
                        insert_plots_with_legend(worksheet, plots, legends)
                        print(f"Created plots sheet: {plot_sheet_name}")
                except Exception as e:
                    print(f"Error creating plots for {sheet_name}: {str(e)}")
        
        # Write threshold analysis sheets if provided
        if thresholds_dict:
            for sheet_name, threshold_df in thresholds_dict.items():
                if not threshold_df.empty:
                    threshold_sheet_name = f"Thresholds_{sheet_name}"
                    threshold_df.to_excel(writer, sheet_name=threshold_sheet_name, index=False)
                    print(f"Saved threshold sheet: {threshold_sheet_name}")
    
    print("Analysis saved successfully to Excel with plots and legends!")


#%%
def display_plots_only(df, title_prefix=""):
    """
    Display plots without saving to Excel - for preview purposes only.
    Shows both sample sizes vs S32 and sample sizes vs Expected plots.
    
    Args:
        df: DataFrame with return period and sample comparison data
        title_prefix: String to add to plot titles (e.g., "EP_GR", "EP_GU")
    """
    import numpy as np
    
    return_period_col = 'ReturnPeriod'
    vs_s32_cols = [col for col in df.columns if col.endswith('vsS32') and col != 'S32vsExpected']
    vs_expected_cols = [col for col in df.columns if col.endswith('vsExpected') and col != 'S32vsExpected']
    
    if return_period_col not in df.columns:
        print("Warning: ReturnPeriod column not found")
        return
    
    cmap = get_cmap('tab20')

    # Plot 1: All sample % differences vs S32
    print(f"\n=== {title_prefix} PLOTS ===")
    fig1, ax1 = plt.subplots(figsize=(12, 8))

    for i, col in enumerate(vs_s32_cols):
        if col in df.columns:
            color = cmap(i % 20)
            ax1.plot(df[return_period_col], df[col], label=col, color=color, linewidth=2)

    ax1.set_xlabel('Return Period')
    ax1.set_ylabel('% Difference from S32')
    ax1.set_title(f'{title_prefix} All Sample % Differences vs S32')
    ax1.grid(True, alpha=0.3)
    ax1.set_xlim((100,1000))
    ax1.set_ylim((-10, 10))
    
    # Set custom axis ticks
    y_ticks = np.arange(-10, 10, 2)
    ax1.set_yticks(y_ticks)
    x_ticks = np.arange(100,1000, 100)
    ax1.set_xticks(x_ticks)
    
    ax1.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.tight_layout()
    plt.show()

    # Plot 2: All sample % differences vs Expected
    if vs_expected_cols:
        fig2, ax2 = plt.subplots(figsize=(12, 8))

        for i, col in enumerate(vs_expected_cols):
            if col in df.columns:
                color = cmap((i + len(vs_s32_cols)) % 20)  # Use different colors
                ax2.plot(df[return_period_col], df[col], label=col, color=color, linewidth=2)

        ax2.set_xlabel('Return Period')
        ax2.set_ylabel('% Difference from Expected')
        ax2.set_title(f'{title_prefix} All Sample % Differences vs Expected')
        ax2.grid(True, alpha=0.3)
        ax2.set_xlim((100,1000))
        ax2.set_ylim((-10, 10))
        
        ax2.set_yticks(y_ticks)
        ax2.set_xticks(x_ticks)
        
        ax2.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
        plt.tight_layout()
        plt.show()

    # Plot 3: S32 vs Expected if available
    if 'S32vsExpected' in df.columns:
        fig3, ax3 = plt.subplots(figsize=(12, 8))
        ax3.plot(df[return_period_col], df['S32vsExpected'], color='red', linewidth=2, label='S32vsExpected')
        ax3.set_xlabel('Return Period')
        ax3.set_ylabel('% Difference from Expected')
        ax3.set_title(f'{title_prefix} S32 vs Expected % Difference')
        ax3.grid(True, alpha=0.3)
        ax3.set_xlim((100,1000))
        ax3.set_ylim((-10, 10))
        
        ax3.set_yticks(y_ticks)
        ax3.set_xticks(x_ticks)
        ax3.legend()
        plt.tight_layout()
        plt.show()

#%%
# MAIN EXECUTION - All function calls happen here
if __name__ == "__main__":
    print("=" * 80)
    print("STARTING PORTFOLIO ANALYSIS PIPELINE")
    print("=" * 80)
    
    # Configuration
    results_base_path = r'D:/AshleyY/NL_Analysis/105'
    output_excel_path = r'D:/AshleyY/NL_Analysis/105/105.xlsx'
    
    # Step 1: Process all data
    print("\nStep 1: Processing EP and Stats Portfolio Data")
    print("-" * 50)
    
    # EP_GR = ep_port_aggregating_files(results_base_path, "GR")
    EP_GU = ep_port_aggregating_files(results_base_path, "GU")
    # STAT_GR = stat_port_aggregating_files(results_base_path, "GR")
    STAT_GU = stat_port_aggregating_files(results_base_path, "GU")
    STAT_RISK_GU = stat_risk_aggregating(results_base_path, "GU")
    # STAT_RISK_GR = stat_risk_aggregating(results_base_path, "GR")

    
    # Step 2: Calculate threshold analysis
    print("\nStep 2: Calculating Threshold Analysis")
    print("-" * 50)
    
    # thresholds_ep_gr = calculate_thresholds(EP_GR) if not EP_GR.empty else pd.DataFrame()
    thresholds_ep_gu = calculate_thresholds(EP_GU) if not EP_GU.empty else pd.DataFrame()
    
    # Print threshold results
    if not thresholds_ep_gu.empty:
        print("\n=== THRESHOLD ANALYSIS RESULTS - EP_GU ===")
        print(thresholds_ep_gu.to_string(index=False))
        print()
        
        # Summary of which sample sizes meet the thresholds
        print("=== THRESHOLD SUMMARY ===")
        for threshold in thresholds_ep_gu['Threshold'].unique():
            threshold_data = thresholds_ep_gu[thresholds_ep_gu['Threshold'] == threshold]
            meeting_threshold = threshold_data[threshold_data['within_threshold?'] == 'Yes']
            
            print(f"\nSample sizes meeting {threshold} threshold:")
            if len(meeting_threshold) > 0:
                sample_sizes = meeting_threshold['Sample_Size'].tolist()
                print(f"  {sample_sizes}")
            else:
                print(f"  None")
    else:
        print("No threshold analysis results available.")
    
    # Step 3: Save everything to Excel
    print("\nStep 3: Saving Complete Analysis to Excel")
    print("-" * 50)
    
    # PLOT DISPLAY OPTIONS:
    # Option 1: Preview plots only (no Excel save) - uncomment lines below to use
    # if not EP_GR.empty:
    #     display_plots_only(EP_GR, "EP_GR") #lines 576-577: EP_GR = ep_port_aggregating_files(results_base_path, "GR"), EP_GU = ep_port_aggregating_files(results_base_path, "GU")

    if not EP_GU.empty:
        print("\n=== DATA SUMMARY - EP_GU ===")
        sample_cols = [col for col in EP_GU.columns if col.startswith('S') and 'vs' not in col and col[1:].isdigit()]
        vs_s32_cols = [col for col in EP_GU.columns if col.endswith('vsS32')]
        vs_expected_cols = [col for col in EP_GU.columns if col.endswith('vsExpected')]
        
        print(f"Available sample sizes: {sorted([int(col[1:]) for col in sample_cols])}")
        print(f"Sample vs S32 comparisons: {len(vs_s32_cols)} columns")
        print(f"Sample vs Expected comparisons: {len(vs_expected_cols)} columns")
        print(f"Return period range: {EP_GU['ReturnPeriod'].min():.0f} - {EP_GU['ReturnPeriod'].max():.0f}")
        print(f"Total data points: {len(EP_GU)}")
        
        display_plots_only(EP_GU, "EP_GU")
    
    # Create dictionaries for the new flexible function
    dataframes_dict = {
        # "EP_PORT_GR": EP_GR,
        "EP_PORT_GU": EP_GU,
        # "STAT_PORT_GR": STAT_GR,
        "STAT_PORT_GU": STAT_GU,
        "STAT_RISK_GU":STAT_RISK_GU,
        # "STAT_RISK_GR":STAT_RISK_GR
    }
    
    thresholds_dict = {
        # "EP_GR": thresholds_ep_gr,
        "EP_GU": thresholds_ep_gu
    }
    
    # # Save using the new flexible function
    # save_complete_analysis_to_excel(
    #     dataframes_dict=dataframes_dict,
    #     thresholds_dict=thresholds_dict,
    #     output_path=output_excel_path,
    #     show_plots=True
    # )
    
    
    # Option 3: Save to Excel without plot preview (faster) - use this instead of above
    # save_complete_analysis_to_excel(
    #     dataframes_dict=dataframes_dict,
    #     thresholds_dict=thresholds_dict,
    #     output_path=output_excel_path,
    #     show_plots=False
    # )
    
    # Step 4: Summary
    print("\n" + "=" * 80)
    print("PIPELINE COMPLETED SUCCESSFULLY")
    print("=" * 80)
    print(f"Output saved to: {output_excel_path}")
    print("\nSummary:")
    # print(f"  EP GR data: {'✓' if not EP_GR.empty else '✗'} ({EP_GR.shape[0] if not EP_GR.empty else 0} rows)")
    print(f"  EP GU data: {'✓' if not EP_GU.empty else '✗'} ({EP_GU.shape[0] if not EP_GU.empty else 0} rows)")
    # print(f"  Stats GR data: {'✓' if not STAT_GR.empty else '✗'} ({STAT_GR.shape[0] if not STAT_GR.empty else 0} rows)")
    print(f"  Stats GU data: {'✓' if not STAT_GU.empty else '✗'} ({STAT_GU.shape[0] if not STAT_GU.empty else 0} rows)")
    