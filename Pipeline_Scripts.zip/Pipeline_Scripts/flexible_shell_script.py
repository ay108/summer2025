import os 
import json
import pandas as pd

# Configuration - Set this flag to control output type
GENERATE_SEPARATE_SCRIPTS = True  # True = separate scripts, False = one consolidated script

#Folders having json files that the shell script references and runs
JsonDir = r'D:\AshleyY\Automated_24_48\json_templates\24'
JSON_PATH_DIR = '/' + JsonDir.replace('\\','/').replace(':','')

#copy folder path/where you want the output files to go
CopyFolder = r'D:\AshleyY\Automated_24_48\Auto_Analysis'
#loss folder path/where the copied folder
ResultFolder='//ca1fs01/me_results/losses-hd'

#Shell Path
Shell_Dir =  r'D:\AshleyY\Automated_24_48'
#Shell file name (for consolidated script)
Shell_Name = 'Submit_EUWS_Automated.sh'
#Change Host and User
HOST = 'ca1md-k8m-dev1-01'
USER ='yashley'

# Extracting .json names from the Folder
NMS = []
for root, dirs, files in os.walk(JsonDir, topdown=True):
    for name in files:
        if name.endswith(".json"):
            NMS.append(name[:len(name)-5])

print(f"Found {len(NMS)} JSON files: {NMS}")
print(f"Mode: {'Separate Scripts' if GENERATE_SEPARATE_SCRIPTS else 'Consolidated Script'}")

#File constants
a = '#!/bin/bash\n\
HOST="'+ HOST  + '"\n\
PORT="5001"\n\
ENDPOINT="profile"\n\
JSON_PATH="'

c = 'JQ_PATH="/c/jq/jq.exe"\n\
USER="'+ USER  + '"\n\
################################\n\
echo "Calling $ENDPOINT job"\n\
status=$(curl -s -u $USER:$USER -XPOST \\\n\
\t\t-d @$JSON_PATH \\\n\
\t\t-H "Content-Type:application/json" http://$HOST:$PORT/$ENDPOINT)\n\
echo $status | $JQ_PATH -C .\n\
JOB_ID=$($JQ_PATH .JobId <<< $status)\n\
WORKFLOW_ID=$($JQ_PATH .Workflowid <<< $status)\n\
URL=$($JQ_PATH .JobURL <<< $status)\n\
MESSAGE=$($JQ_PATH .ErrorMessage <<< $status)\n\
echo $status > $JOB_ID\_run.json\n\
echo $JOB_ID\n\
echo $WORKFLOW_ID\n\
echo $URL\n\
echo $MESSAGE\n'

c1b = 'STATUSENDPOINT="getjobstatus"\n\
echo $JOB_ID\n\
status=$(curl -s -u $USER:$USER -XGET \\\n\
\t\t-H "Content-Type:application/json" http://$HOST:$PORT/$STATUSENDPOINT/$JOB_ID)\n\
$JQ_PATH -C . <<< $status\n\
CurrentStatus=$($JQ_PATH .status <<< $status)\n\
echo "curl -u test:test -XGET http://$HOST:$PORT/getjobstatus/$JOB_ID"\n\
while [ "$CurrentStatus" != "Succeeded" ]\n\
do\n\
    JOBSTATUS=$(curl -s -u $USER:$USER -XGET  http://$HOST:$PORT/getjobstatus/$JOB_ID)\n\
\tCurrentStatus=$($JQ_PATH .status <<< $JOBSTATUS)\n\
\techo "Current job status is $CurrentStatus"\n\
\tif [[ "$CurrentStatus" =~ "Succeeded" ]]; then\n\
    echo "Run PostProcess scritps"\n'

e = '\t\tbreak\n\
    fi\n\
\tif [[ "$CurrentStatus" =~ "Failed" ]]; then\n\
    echo "Run PostProcess scritps"\n'
f_string = '\t\tbreak\n\
    fi\n\
\techo "Sleep for 600 seconds.."\n\
\tsleep 600\n\
done\n'

# Initialize file handling based on mode
if GENERATE_SEPARATE_SCRIPTS:
    # For separate scripts, we'll create files in the loop
    consolidated_file = None
else:
    # For consolidated script, create one file now
    consolidated_file = open(Shell_Dir+'\\' + Shell_Name,'w')

j = 0
while j < len(NMS):
    json_file_path = JsonDir + '\\' + NMS[j] + '.json'
    print(f"Processing file {j+1}/{len(NMS)}: {json_file_path}")
    
    # Check if file exists
    if not os.path.exists(json_file_path):
        print(f"ERROR: File does not exist: {json_file_path}")
        j += 1
        continue
    
    # Check file size
    file_size = os.path.getsize(json_file_path)
    print(f"File size: {file_size} bytes")
    
    if file_size == 0:
        print(f"ERROR: File is empty: {json_file_path}")
        j += 1
        continue
    
    try:
        # Try to read and parse the JSON file
        with open(json_file_path, 'r', encoding='utf-8') as file_obj:
            file_content = file_obj.read()
            
        ReadJson = json.loads(file_content)
        print(f"Successfully parsed JSON for: {NMS[j]}")
        
    except json.JSONDecodeError as e:
        print(f"JSONDecodeError for file {json_file_path}: {e}")
        print(f"Error at line {e.lineno}, column {e.colno}")
        print(f"Error message: {e.msg}")
        j += 1
        continue
    except Exception as e:
        print(f"Unexpected error reading {json_file_path}: {e}")
        j += 1
        continue
    
    # Handle file creation based on mode
    if GENERATE_SEPARATE_SCRIPTS:
        # Create individual shell script for this analysis
        shell_script_name = f'Submit_{NMS[j]}.sh'
        text_file = open(Shell_Dir+'\\' + shell_script_name,'w')
    else:
        # Use the consolidated file
        text_file = consolidated_file
    
    # Ensure text_file is not None before writing
    if text_file is not None:
        # Write the shell script content
        text_file.write(a)
        b = JSON_PATH_DIR + '/' + NMS[j] + '.json"\n'
        text_file.write(b)

        c1 = 'CopyFolder='+CopyFolder+'\n'
        c2 = 'ResultFolder='+ResultFolder+'\n'
        text_file.write(c1)
        text_file.write(c2)
        
        text_file.write(c)
        c1a = 'mkdir -p $CopyFolder' + '/' + NMS[j] + '_$JOB_ID'+'\n'
        text_file.write(c1a)
        text_file.write(c1b)
        
        text_file.write('\techo "Copy Results"\n')   
        d1 = '\t'+'cp -r $ResultFolder/$JOB_ID/Stats $CopyFolder'+'/'+ NMS[j]+'_$JOB_ID\n'
        d2 = '\t'+'cp -r $ResultFolder/$JOB_ID/EP $CopyFolder'+'/'+ NMS[j]+'_$JOB_ID\n'
        d3 = '\t'+'cp -r $ResultFolder/$JOB_ID/PLT $CopyFolder'+'/'+ NMS[j]+'_$JOB_ID\n'
        d5 = '\t'+'cp -r $ResultFolder/$JOB_ID/EventStats $CopyFolder'+'/'+ NMS[j]+'_$JOB_ID\n'
        d6 = '\t'+'cp -r $ResultFolder/$JOB_ID/SLT $CopyFolder'+'/'+ NMS[j]+'_$JOB_ID\n'
        d7 = '\t'+'cp -r $ResultFolder/$JOB_ID/job_input.json $CopyFolder'+'/'+ NMS[j]+'_$JOB_ID\n'
        d8 = '\t'+'cp -r $ResultFolder/$JOB_ID/FullEP $CopyFolder'+'/'+ NMS[j]+'_$JOB_ID\n'
        
        text_file.write(d1)
        text_file.write('\techo "Results Copied"\n')
        text_file.write(d2)
        text_file.write('\techo "Results Copied"\n')
        text_file.write(d3)
        text_file.write('\techo "Results Copied"\n')
        text_file.write(d5)
        text_file.write('\techo "Results Copied"\n')
        text_file.write(d6)
        text_file.write('\techo "Results Copied"\n') 
        text_file.write(d7)
        text_file.write('\techo "Results Copied"\n') 
        text_file.write(d8)
        text_file.write('\techo "Results Copied"\n') 
        text_file.write(f_string)
        
        # Handle file closing based on mode
        if GENERATE_SEPARATE_SCRIPTS:
            text_file.close()
            print(f"Created shell script: {shell_script_name}")
        # For consolidated mode, don't close yet - keep writing to the same file
    
    j += 1

# Final cleanup
if not GENERATE_SEPARATE_SCRIPTS and consolidated_file:
    consolidated_file.close()
    print(f"Created consolidated shell script: {Shell_Name}")

print("Script completed successfully!")
if GENERATE_SEPARATE_SCRIPTS:
    print(f"Created {len(NMS)} separate shell scripts in {Shell_Dir}")
else:
    print(f"Created 1 consolidated shell script in {Shell_Dir}") 