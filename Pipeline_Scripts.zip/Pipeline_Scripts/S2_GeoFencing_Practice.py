#trying out S2 Geometry library 
#first convert lat/lon to S2Point
#use S2LatLng and S2CellId to do approximate spatial search
#use spatial index (dictionary) to simulate fast lookup on small dataset

from s2sphere import LatLng, CellId
import pandas as pd
import math 
import heapq
import json

class S2SpatialIndex:
    def __init__(self, level=15):
        self.level = level #S2 cell level -- higher = more precise
        self.index = {}
        
    def _latlon_to_cell_id(self, lat, lon):
        latlng = LatLng.from_degrees(lat, lon)
        return CellId.from_lat_lng(latlng).parent(self.level)

    def _haversine(self, lat1, lon1, lat2, lon2):
        R = 6371e3  # Earth radius in meters
        phi1 = math.radians(lat1)
        phi2 = math.radians(lat2)
        delta_phi = math.radians(lat2 - lat1)
        delta_lambda = math.radians(lon2 - lon1)

        a = math.sin(delta_phi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2) ** 2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        return R * c
    
    def add_point(self, point):
        """ 
        point : dictionary with at least {'lat':..., 'lon':...}
        """
        cell_id = self._latlon_to_cell_id(point['lat'], point['lon'])
        self.index.setdefault(cell_id, []).append(point)

    def query(self, lat, lon, k=4):
        """
        returns the k nearest neighbors to (lat, lon)
        """
        query_cell = CellId.from_lat_lng(LatLng.from_degrees(lat, lon)).parent(self.level)
        #this allows us to group the nearby points together
        #"group this lat/lon into a spatial bin that covers the size of a region corresponding to a S2 level specified"
        #parent refers to spatial hierarchy, not the inheritance
        neighbors = [query_cell] + list(query_cell.get_all_neighbors(self.level))
        #query_cell.id() returns the 64-bit integer ID of the cell that contains your query point
        #aka the current cell where your query point is located
        #query_cell.get_all_neighbors(self.level) returns all neighboring cells at the specified level
        candidates = []
        for cell in neighbors:
            candidates.extend(self.index.get(cell, []))

        heap = []
        for i, point in enumerate(candidates):
            dist= self._haversine(lat, lon, point['lat'], point['lon'])
            heapq.heappush(heap, (dist, i, point))
        
        results = []
        for _ in range(min(k, len(heap))):
            if heap:
                results.append(heapq.heappop(heap)[2])
                #heapq.heappop(heap) returns the smallest element from the heap
                #heap[2] is the third element of the tuple (the point)
        return results
    

def brute_force_nearest_neighbors(query_lat, query_lon, all_points, k=4):
    """
    Brute force method: calculate distance to all points and return k nearest
    """
    def haversine(lat1, lon1, lat2, lon2):
        R = 6371e3  # Earth radius in meters
        phi1 = math.radians(lat1)
        phi2 = math.radians(lat2)
        delta_phi = math.radians(lat2 - lat1)
        delta_lambda = math.radians(lon2 - lon1)

        a = math.sin(delta_phi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2) ** 2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        return R * c
    
    distances = []
    for point in all_points:
        dist = haversine(query_lat, query_lon, point['lat'], point['lon'])
        distances.append((dist, point))
    
    # Sort by distance and return k nearest
    distances.sort(key=lambda x: x[0])
    return [point for dist, point in distances[:k]]


def load_geojson_data(file_path=None):
    """
    Load GeoJSON data either from a file or return sample data
    """
    if file_path:
        with open(file_path, 'r') as f:
            return json.load(f)

geojson_data = load_geojson_data(r"C:\Users\yanga3\Downloads\test_shp.geojson")


all_points = []
index = S2SpatialIndex(level=8)  

for feature in geojson_data['features']:
    props = feature['properties']
    point = {
        'location_id': props['GDMID'],  #GDMID is the unique identifier for each point
        'lat': props['LATITUDE'],
        'lon': props['LONGITUDE'],
    }
    index.add_point(point)
    all_points.append(point)

#using first fearture as the query point
query_feature = geojson_data['features'][0]
query_lat = query_feature['properties']['LATITUDE']
query_lon = query_feature['properties']['LONGITUDE']

print(f"Query point: {query_feature['properties']['GDMID']} at ({query_lat}, {query_lon})")
print("***************************************")

#s2 spatial index method
import time
start_time = time.time()
s2_neighbors = index.query(query_lat, query_lon, k=8)
s2_duration = time.time() - start_time
print(f"S2 neighbors: {len(s2_neighbors)}")
print(f"S2 time elapsed: {s2_duration:.6f} seconds")

for i, neighbor in enumerate(s2_neighbors, 1):
    #print out the location id, long, and lat
    print(f"{i}. {neighbor['location_id']} ({neighbor['lat']}, {neighbor['lon']})")
print("***************************************")

# brute force method
start_time_brute = time.time()
brute_neighbors = brute_force_nearest_neighbors(query_lat, query_lon, all_points, k=8)
brute_duration = time.time() - start_time_brute
print(f"Brute force neighbors: {len(brute_neighbors)}")
print(f"Brute force time elapsed: {brute_duration:.6f} seconds")

for i, neighbor in enumerate(brute_neighbors, 1):
    print(f"{i}. {neighbor['location_id']} ({neighbor['lat']}, {neighbor['lon']})")

print("***************************************")

s2_ids = [neighbor['location_id'] for neighbor in s2_neighbors]
brute_ids = [neighbor['location_id'] for neighbor in brute_neighbors]

if set(s2_ids) == set(brute_ids):
    print(" same")
else:
    print("different")
    print(f"S2 method: {s2_ids}")
    print(f"Brute force: {brute_ids}")
    

print(f"query point Id: {query_feature['properties']['GDMID']}")
