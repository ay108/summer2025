#querying nearby points
import duckdb
import math
import heapq
from s2sphere import LatLng, CellId
from functools import lru_cache

PARTITIONED_PARQUET_DIR = "data/points_partitioned"
S2_LEVEL = 10

def haversine(lat1, lon1, lat2, lon2):
    R = 6371e3
    phi1, phi2 = map(math.radians, [lat1, lat2])
    d_phi = math.radians(lat2 - lat1)
    d_lambda = math.radians(lon2 - lon1)
    a = math.sin(d_phi/2)**2 + math.cos(phi1)*math.cos(phi2)*math.sin(d_lambda/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

def latlon_to_cell_id(lat, lon, level=S2_LEVEL):
    return CellId.from_lat_lng(LatLng.from_degrees(lat, lon)).parent(level)

@lru_cache(maxsize=1024)
def load_points_for_cell(cell_id: int):
    query = f"""
    SELECT * FROM '{PARTITIONED_PARQUET_DIR}' 
    WHERE s2_cell_id = {cell_id}
    """
    return duckdb.query(query).to_df().to_dict(orient='records')

def query_nearest_neighbors(lat, lon, k=5):
    query_cell = latlon_to_cell_id(lat, lon)
    neighbor_cells = [query_cell] + list(query_cell.get_all_neighbors(S2_LEVEL))
    
    candidates = []
    for cell in neighbor_cells:
        candidates.extend(load_points_for_cell(int(cell.id())))

    heap = []
    for i, pt in enumerate(candidates):
        dist = haversine(lat, lon, pt['lat'], pt['lon'])
        heapq.heappush(heap, (dist, i, pt))

    return [heapq.heappop(heap)[2] for _ in range(min(k, len(heap)))]
