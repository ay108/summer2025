import os
import pandas as pd

def universal_aggregating_files(portfolio_number, expected_id, portfolio_numbers, loss_type, analysis_type, base_data_path=None):
    """
    Universal function to aggregate files for different analysis types.
    
    Parameters:
    - portfolio_number: The portfolio number
    - expected_id: The expected ID
    - portfolio_numbers: List of portfolio numbers to process (for stat_risk) or single number for others
    - loss_type: The loss type (e.g., "GU", "GR")
    - analysis_type: "ep_portfolio", "stat_portfolio", "stat_risk"
    - base_data_path: Base path to data folder (if None, uses default Downloads folder)
    
    Returns:
    - DataFrame or concatenated DataFrame for stat_risk
    """
    
    # Define portfolio configurations
    dk_port1 = {
        206072:1, 
        206076:5, 
        206077:10, 
        206079:16, 
        206080:32
    }
    
    nl_port1 = {
        202807:1,
        202819:2,
        202821:4,
        202809:5,
        202826:6,
        202811:10,
        202827:12,
        202894:16,
        202831:24,
        202837:32
    }

    nl_port2 = {
        202856:1,
        202857:2,
        202870:4,
        202885:5,
        202871:6,
        202886:10,
        202887:12 ,
        202890:16,
        203180:24,
        202906:32
    }

    nl_port3 = {
        202909:1,
        202910:2,
        202911:4,
        202916:5,
        202914:6,
        202919:10,
        202920:12,
        202922:16,
        202926:24,
        202939:32
    }

    nl_port4= {
        202948:1,
        202953:2,
        202993:4,
        202994:5,
        202995:6,
        202996:10,
        202997:12,
        202999:16,
        203001:24,
        205850:32
    }
    
    # Set default base path if not provided
    if base_data_path is None:
        #set this to your preferred path
        base_data_path = r'C:\Users\yanga3\Downloads'
    
    # Set up all portfolios
    portfolios = {1: dk_port1, 2: nl_port1, 3: nl_port2, 4: nl_port3, 5: nl_port4}
    
    # Ensure portfolio_numbers is always a list
    if isinstance(portfolio_numbers, int):
        portfolio_numbers = [portfolio_numbers]
    
    all_dfs = []
    
    # Process each portfolio
    for port_num in portfolio_numbers:
        portfolio = portfolios[port_num]
        df = pd.DataFrame()
        
        # Set up paths and file names based on analysis type
        if analysis_type == "ep_portfolio":
            dataset_folder = "DK_RES_GC_0"
            expected_path = rf'{base_data_path}\{dataset_folder}\{portfolio_number}\{expected_id}\EP\Portfolio\{loss_type}\EP100.parquet'
            job_path_template = rf'{base_data_path}\{dataset_folder}\{portfolio_number}\{{job_id}}\EP\Portfolio\{loss_type}\EP100.parquet'
            data_column = 'Loss'
        elif analysis_type == "stat_portfolio":
            dataset_folder = "DK_RES_GC_0"
            expected_path = rf'{base_data_path}\{dataset_folder}\{portfolio_number}\{expected_id}\Stats\Portfolio\{loss_type}\Stats100.parquet'
            job_path_template = rf'{base_data_path}\{dataset_folder}\{portfolio_number}\{{job_id}}\Stats\Portfolio\{loss_type}\Stats100.parquet'
            data_column = 'AAL'
        elif analysis_type == "stat_risk":
            dataset_folder = "NL_Analysis"
            expected_path = rf'{base_data_path}\{dataset_folder}\{portfolio_number}\{expected_id}\Stats\Risk\{loss_type}\Stats100.parquet'
            job_path_template = rf'{base_data_path}\{dataset_folder}\{portfolio_number}\{{job_id}}\Stats\Risk\{loss_type}\Stats100.parquet'
            data_column = 'AAL'
        
        # Load expected file
        if os.path.exists(expected_path):
            df = pd.read_parquet(expected_path)
            df['Expected'] = df[data_column]
        else:
            print(f"Expected file not found: {expected_path}")
            continue
        
        # Process job files
        for job_id, sample_size in portfolio.items():
            file_path = job_path_template.format(job_id=job_id)
            if os.path.exists(file_path):
                df_temp = pd.read_parquet(file_path)
                
                if analysis_type == "stat_risk":
                    # For stat_risk, use merge operation
                    df_temp = df_temp[['LocationId', data_column]].rename(columns={data_column: f'S{sample_size}'})
                    df = df.merge(df_temp, on='LocationId', how='inner')
                else:
                    # For others, direct assignment
                    df[f'S{sample_size}'] = df_temp[data_column]
            else:
                print(f"Missing file for job ID {job_id}: {file_path}")
        
        # Calculate differences and percentages vs S32
        for sample_size in portfolio.values():
            s_col = f'S{sample_size}'
            if sample_size != 32 and s_col in df.columns and 'S32' in df.columns:
                df[f'{s_col}VSS32'] = (df[s_col] - df['S32']) / df['S32'] * 100
        
        if 'S32' in df.columns and 'Expected' in df.columns:
            df['S32vsExpected'] = (df['S32'] - df['Expected']) / df['Expected'] * 100
        
        # Reorder columns
        base_cols = [col for col in df.columns if not col.startswith('S') or col == 'S32vsExpected']
        
        s_cols = sorted(
            [col for col in df.columns if col.startswith('S') and 'vs' not in col and col[1:].isdigit()],
            key=lambda x: int(x[1:])
        )
        
        vs_cols = sorted(
            [col for col in df.columns if 'VSS32' in col and col[1:col.find('V')].isdigit()],
            key=lambda x: int(x[1:x.find('V')])
        )
        
        if 'S32vsExpected' in base_cols:
            base_cols.remove('S32vsExpected')
        
        new_order = base_cols + s_cols + vs_cols
        if 'S32vsExpected' in df.columns:
            new_order += ['S32vsExpected']
        
        df = df[new_order]
        
        # Apply EP-specific filter
        if analysis_type == "ep_portfolio":
            df = df[df['EPType'] == 'OEP']
        
        if not df.empty:
            all_dfs.append(df)
    
    # Return results
    if len(all_dfs) == 0:
        return pd.DataFrame()
    elif len(all_dfs) == 1:
        return all_dfs[0]
    else:
        # For multiple portfolios (mainly stat_risk), concatenate
        return pd.concat(all_dfs, ignore_index=True)
def calculate_thresholds(df, threshold_percentages=[1, 5, 10]):
    """
    Calculate threshold analysis for convergence assessment.
    
    Args:
        df: DataFrame with sample columns (S1, S2, etc.) and S32vsExpected
        threshold_percentages: List of threshold percentages to analyze
    
    Returns:
        DataFrame with threshold analysis results
    """
    print("Calculating threshold analysis...")
    
    results = []
    
    # Get sample columns (excluding S32 and comparison columns)
    sample_cols = [col for col in df.columns if col.startswith('S') and 'vs' not in col and col != 'S32' and col[1:].isdigit()]
    sample_cols = sorted(sample_cols, key=lambda x: int(x[1:]))
    
    if 'S32vsExpected' not in df.columns:
        print("Warning: S32vsExpected column not found")
        return pd.DataFrame()
    
    for threshold in threshold_percentages:
        for sample_col in sample_cols:
            if f'{sample_col}VSS32' in df.columns:
                # Count how many values are within threshold
                within_threshold = (abs(df[f'{sample_col}VSS32']) <= threshold).sum()
                total_count = len(df[f'{sample_col}VSS32'].dropna())
                percentage_within = (within_threshold / total_count * 100) if total_count > 0 else 0
                
                results.append({
                    'Sample': sample_col,
                    'Sample_Size': int(sample_col[1:]),
                    'Threshold_%': threshold,
                    'Within_Threshold_Count': within_threshold,
                    'Total_Count': total_count,
                    'Percentage_Within_Threshold': percentage_within
                })
    
    # Also analyze S32vsExpected
    for threshold in threshold_percentages:
        within_threshold = (abs(df['S32vsExpected']) <= threshold).sum()
        total_count = len(df['S32vsExpected'].dropna())
        percentage_within = (within_threshold / total_count * 100) if total_count > 0 else 0
        
        results.append({
            'Sample': 'S32vsExpected',
            'Sample_Size': 32,
            'Threshold_%': threshold,
            'Within_Threshold_Count': within_threshold,
            'Total_Count': total_count,
            'Percentage_Within_Threshold': percentage_within
        })
    
    threshold_df = pd.DataFrame(results)
    print(f"Threshold analysis completed for {len(sample_cols)} samples and S32vsExpected")
    
    return threshold_df


# Example usage with threshold analysis:

# For EP Portfolio - using default path
print("Processing EP Portfolio data...")
df1 = universal_aggregating_files(75, 201894, 1, "GU", "ep_portfolio")

# For Stats Portfolio - using custom path
print("Processing Stats Portfolio data...")
df2 = universal_aggregating_files(75, 201894, 1, "GU", "stat_portfolio")

# For Stats Risk with concatenation - using custom path
print("Processing Stats Risk data...")
df3 = universal_aggregating_files(75, 201894, [1, 2, 3, 4], "GU", "stat_risk")

# Calculate threshold analysis for each dataset
print("\nCalculating threshold analysis...")
thresholds_ep = calculate_thresholds(df1) if not df1.empty else pd.DataFrame()
thresholds_stat = calculate_thresholds(df2) if not df2.empty else pd.DataFrame()
thresholds_risk = calculate_thresholds(df3) if not df3.empty else pd.DataFrame()

# Save to Excel with threshold analysis
output_path = r'C:\Users\yanga3\Downloads\aggregation_results_with_thresholds.xlsx'
print(f"\nSaving results to: {output_path}")

with pd.ExcelWriter(output_path) as writer:
    # Main data sheets
    if not df1.empty:
        df1.to_excel(writer, sheet_name='EP_Portfolio', index=False)
    if not df2.empty:
        df2.to_excel(writer, sheet_name='Stats_Portfolio', index=False)
    if not df3.empty:
        df3.to_excel(writer, sheet_name='Stats_Risk', index=False)
    
    # Threshold analysis sheets
    if not thresholds_ep.empty:
        thresholds_ep.to_excel(writer, sheet_name='Thresholds_EP', index=False)
    if not thresholds_stat.empty:
        thresholds_stat.to_excel(writer, sheet_name='Thresholds_Stats', index=False)
    if not thresholds_risk.empty:
        thresholds_risk.to_excel(writer, sheet_name='Thresholds_Risk', index=False)

print("Processing completed successfully!")

