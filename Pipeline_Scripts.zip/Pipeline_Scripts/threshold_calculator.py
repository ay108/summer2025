#find which sample # is within the threshold of +/- 1% and 2% for ALL sheets
import pandas as pd

# Read all sheets from the Excel file
excel_file = r'C:\Users\yanga3\Downloads\Book4.xlsx'
all_sheets = pd.read_excel(excel_file, sheet_name=None, header=0, index_col=0)

#look for the columns: 
columns = ['S1vsS32', 'S2vsS32', 'S4vsS32', 'S5vsS32', 'S6vsS32','S10vsS32', 'S12vsS32', 'S16vsS32', 'S24vsS32']

# Store results for all sheets
results = {}

# Loop through each sheet
for sheet_name, df in all_sheets.items():
    print(f"ANALYZING SHEET: {sheet_name}")
    #only want the rows where return period is between 100 and 1000
    if 'ReturnPeriod' in df.columns:
        df = df[(df['ReturnPeriod'] >= 100) & (df['ReturnPeriod'] <= 1000)]
        print(f"Filtered to {len(df)} rows (return periods 100-1000)")

    # Debug: Show what columns are actually available
    print(f"Available columns in {sheet_name}: {list(df.columns)}")
    
    # Skip if the required columns don't exist
    missing_cols = [col for col in columns if col not in df.columns]
    if missing_cols:
        print(f"Missing columns in {sheet_name}: {missing_cols}")
        continue
    
    # Only keep when the return period is between 100 and 1000
    if 'ReturnPeriod' in df.columns:
        df_filtered = df[(df['ReturnPeriod'] >= 100) & (df['ReturnPeriod'] <= 1000)]
        print(f"Filtered to {len(df_filtered)} rows (return periods 100-1000)")
    else:
        df_filtered = df
        print(f"No ReturnPeriod column found, using all {len(df_filtered)} rows")
    
    # Initialize for this sheet
    min_samples_needed_1 = None
    min_samples_needed_2 = None

    for col in columns:
        # Extract the sample number from column name 
        # Handle both 'S12VS32' and 'S#VSS32' formats
        if 'vs32' in col and 'vsS32' not in col:  # S12VS32 case
            sample_num = int(col.split('vs32')[0][1:])  # Remove 'S' prefix and 'VS32' suffix
        else:  # S#VSS32 case
            sample_num = int(col.split('vsS32')[0][1:])  # Remove 'S' prefix and 'VSS32' suffix
        
        # Debug: Show the actual max value for each column
        max_val = max(abs(df_filtered[col]))
        max_val_percent = max_val * 100  # Convert to percentage for display
        print(f"{col}: max absolute value = {max_val:.6f} (={max_val_percent:.2f}%)")
        
        # Check if this sample size meets the 1% threshold
        # Data is in decimal format (0.01 = 1%)
        if max_val < 0.01:  # Less than 1% (0.01 in decimal)
            if min_samples_needed_1 is None:  # Only set if we haven't found one yet
                min_samples_needed_1 = sample_num
        
        # Check if this sample size meets the 2% threshold  
        if max_val < 0.02:  # Less than 2% (0.02 in decimal)
            if min_samples_needed_2 is None:  # Only set if we haven't found one yet
                min_samples_needed_2 = sample_num

    # Store results for this sheet
    results[sheet_name] = {
        '1%_threshold': min_samples_needed_1,
        '2%_threshold': min_samples_needed_2
    }
    
    print(f"\nRESULTS FOR {sheet_name}:")
    print(f"Minimum samples needed for ±1% threshold: {min_samples_needed_1}")
    print(f"Minimum samples needed for ±2% threshold: {min_samples_needed_2}")

# Print summary of all results
print(f"\n{'='*60}")
print("SUMMARY FOR ALL SHEETS")
print(f"{'='*60}")
print(f"{'Sheet Name':<20} {'±1% Threshold':<15} {'±2% Threshold':<15}")
print("-" * 60)
for sheet, result in results.items():
    print(f"{sheet:<20} {str(result['1%_threshold']):<15} {str(result['2%_threshold']):<15}")

