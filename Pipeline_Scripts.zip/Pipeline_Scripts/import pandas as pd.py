import pandas as pd
import xlsxwriter
from matplotlib.cm import get_cmap
from matplotlib.colors import to_hex
import matplotlib.pyplot as plt
import io
import os
import re

# =============================================================================
# DATA AGGREGATION FUNCTIONS
# =============================================================================

def ep_port_aggregating_files(results_base_path, loss_type):
    """
    Aggregates EP portfolio files from Results directory.
    Expected folder and sample folders are all at the same level in Results directory.
    
    Args:
        results_base_path: Path to Results directory containing all folders
        loss_type: "GU" or "GR"
    """
    print(f"Processing EP Portfolio data for Loss Type: {loss_type}")
    print(f"Results Directory: {results_base_path}")
    
    df = pd.DataFrame()
    sample_sizes = []
    
    # Validate loss_type
    if loss_type not in ['GU', 'GR']:
        print(f"Warning: Unexpected loss_type '{loss_type}'. Expected 'GU' or 'GR'")
        return pd.DataFrame()
    
    if not os.path.exists(results_base_path):
        print(f"Results directory not found: {results_base_path}")
        return pd.DataFrame()
    
    result_folders = [d for d in os.listdir(results_base_path) 
                     if os.path.isdir(os.path.join(results_base_path, d))]
    
    print(f"Found {len(result_folders)} folders")
    
    # Step 1: Find and load the Expected folder
    expected_found = False
    for folder_name in result_folders:
        if "Expected" in folder_name:
            folder_path = os.path.join(results_base_path, folder_name)
            expected_file_path = os.path.join(folder_path, "EP", "Portfolio", loss_type, "EP100.parquet")
            
            if os.path.exists(expected_file_path):
                df = pd.read_parquet(expected_file_path)
                df['Expected'] = df['Loss']
                df['LossType'] = loss_type
                expected_found = True
                print(f"Loaded Expected data from folder: {folder_name}")
                break
    
    if not expected_found:
        print(f"No Expected folder found for {loss_type}")
        return pd.DataFrame()
    
    # Step 2: Process all sample folders
    processed_files = 0
    for folder_name in result_folders:
        if "Expected" not in folder_name:  # Skip the Expected folder
            folder_path = os.path.join(results_base_path, folder_name)
            sample_file_path = os.path.join(folder_path, "EP", "Portfolio", loss_type, "EP100.parquet")
            
            if os.path.exists(sample_file_path):
                try:
                    df_temp = pd.read_parquet(sample_file_path)
                    
                    # Extract sample size from folder name
                    sample_size = None
                    match = re.search(r'_S(\d+)_', folder_name)
                    if match:
                        sample_size = int(match.group(1))
                    else:
                        # Fallback: use processed count + 1
                        sample_size = processed_files + 1
                    
                    # Add sample column
                    column_name = f'S{sample_size}'
                    df[column_name] = df_temp['Loss']
                    sample_sizes.append(sample_size)
                    processed_files += 1
                    print(f"Added {loss_type} sample from {folder_name}: {column_name}")
                    
                except Exception as e:
                    print(f"Error processing {folder_name}: {str(e)}")
                    continue
    
    sample_sizes.sort()
    print(f"Processed {processed_files} sample folders")
    print(f"Sample sizes: {sample_sizes}")
    
    # Calculate differences vs S32
    for sample_size in sample_sizes:
        s_col = f'S{sample_size}'
        if sample_size != 32 and s_col in df.columns and 'S32' in df.columns:
            df[f'{s_col}VSS32'] = (df[s_col] - df['S32']) / df['S32'] * 100

    # Calculate S32 vs Expected (this is the key comparison)
    if 'S32' in df.columns and 'Expected' in df.columns:
        df['S32vsExpected'] = (df['S32'] - df['Expected']) / df['Expected'] * 100

    # Reorder columns
    base_cols = [col for col in df.columns if not col.startswith('S') or col == 'S32vsExpected']

    s_cols = sorted(
        [col for col in df.columns if col.startswith('S') and 'vs' not in col and col[1:].isdigit()],
        key=lambda x: int(x[1:])
    )

    vs_cols = sorted(
        [col for col in df.columns if 'VSS32' in col and col[1:col.find('V')].isdigit()],
        key=lambda x: int(x[1:x.find('V')])
    )

    if 'S32vsExpected' in base_cols:
        base_cols.remove('S32vsExpected')

    new_order = base_cols + s_cols + vs_cols + ['S32vsExpected']
    df = df[new_order]

    # Filter to only OEP data
    if 'EPType' in df.columns:
        df = df[df['EPType'] == 'OEP']

    return df


def stat_port_aggregating_files(results_base_path, loss_type):
    """
    Aggregates Stats portfolio files from Results directory.
    Expected folder and sample folders are all at the same level in Results directory.
    Uses AAL (Average Annual Loss) instead of Loss.
    
    Args:
        results_base_path: Path to Results directory containing all folders
        loss_type: "GU" or "GR"
    """
    
    print(f"Processing Stats Portfolio data for Loss Type: {loss_type}")
    print(f"Results Directory: {results_base_path}")
    
    df = pd.DataFrame()
    sample_sizes = []
    
    # Validate loss_type
    if loss_type not in ['GU', 'GR']:
        print(f"Warning: Unexpected loss_type '{loss_type}'. Expected 'GU' or 'GR'")
        return pd.DataFrame()
    
    if not os.path.exists(results_base_path):
        print(f"Results directory not found: {results_base_path}")
        return pd.DataFrame()
    
    result_folders = [d for d in os.listdir(results_base_path) 
                     if os.path.isdir(os.path.join(results_base_path, d))]
    
    print(f"Found {len(result_folders)} folders")
    
    # Step 1: Find and load the Expected folder
    expected_found = False
    for folder_name in result_folders:
        if "Expected" in folder_name:
            folder_path = os.path.join(results_base_path, folder_name)
            expected_file_path = os.path.join(folder_path, "Stats", "Portfolio", loss_type, "Stats100.parquet")
            
            if os.path.exists(expected_file_path):
                df = pd.read_parquet(expected_file_path)
                df['Expected'] = df['AAL']  # Use AAL for stats instead of Loss
                df['LossType'] = loss_type
                expected_found = True
                print(f"Loaded Expected data from folder: {folder_name}")
                break
    
    if not expected_found:
        print(f"No Expected folder found for {loss_type}")
        return pd.DataFrame()
    
    # Step 2: Process all sample folders
    processed_files = 0
    for folder_name in result_folders:
        if "Expected" not in folder_name:  # Skip the Expected folder
            folder_path = os.path.join(results_base_path, folder_name)
            sample_file_path = os.path.join(folder_path, "Stats", "Portfolio", loss_type, "Stats100.parquet")
            
            if os.path.exists(sample_file_path):
                try:
                    df_temp = pd.read_parquet(sample_file_path)
                    
                    # Extract sample size from folder name
                    sample_size = None
                    match = re.search(r'_S(\d+)_', folder_name)
                    if match:
                        sample_size = int(match.group(1))
                    else:
                        # Fallback: use processed count + 1
                        sample_size = processed_files + 1
                    
                    # Add sample column using AAL
                    column_name = f'S{sample_size}'
                    df[column_name] = df_temp['AAL']  # Use AAL for stats instead of Loss
                    sample_sizes.append(sample_size)
                    processed_files += 1
                    print(f"Added {loss_type} sample from {folder_name}: {column_name}")
                    
                except Exception as e:
                    print(f"Error processing {folder_name}: {str(e)}")
                    continue
    
    sample_sizes.sort()
    print(f"Processed {processed_files} sample folders")
    print(f"Sample sizes: {sample_sizes}")
    
    # Calculate differences vs S32
    for sample_size in sample_sizes:
        s_col = f'S{sample_size}'
        if sample_size != 32 and s_col in df.columns and 'S32' in df.columns:
            df[f'{s_col}VSS32'] = (df[s_col] - df['S32']) / df['S32'] * 100

    # Calculate S32 vs Expected (this is the key comparison)
    if 'S32' in df.columns and 'Expected' in df.columns:
        df['S32vsExpected'] = (df['S32'] - df['Expected']) / df['Expected'] * 100

    # Reorder columns (same as original stats function)
    base_cols = [col for col in df.columns if not col.startswith('S') or col == 'S32vsExpected']

    s_cols = sorted(
        [col for col in df.columns if col.startswith('S') and 'vs' not in col and col[1:].isdigit()],
        key=lambda x: int(x[1:])
    )

    vs_cols = sorted(
        [col for col in df.columns if 'VSS32' in col and col[1:col.find('V')].isdigit()],
        key=lambda x: int(x[1:x.find('V')])
    )

    if 'S32vsExpected' in base_cols:
        base_cols.remove('S32vsExpected')

    new_order = base_cols + s_cols + vs_cols
    if 'S32vsExpected' in df.columns:
        new_order += ['S32vsExpected']
    df = df[new_order]

    return df


def calculate_thresholds(df, threshold_percentages=[1, 5, 10]):
    """
    Calculate threshold analysis for convergence assessment.
    
    Args:
        df: DataFrame with sample columns (S1, S2, etc.) and S32vsExpected
        threshold_percentages: List of threshold percentages to analyze
    
    Returns:
        DataFrame with threshold analysis results
    """
    print("Calculating threshold analysis...")
    
    results = []
    
    # Get sample columns (excluding S32 and comparison columns)
    sample_cols = [col for col in df.columns if col.startswith('S') and 'vs' not in col and col != 'S32' and col[1:].isdigit()]
    sample_cols = sorted(sample_cols, key=lambda x: int(x[1:]))
    
    if 'S32vsExpected' not in df.columns:
        print("Warning: S32vsExpected column not found")
        return pd.DataFrame()
    
    for threshold in threshold_percentages:
        for sample_col in sample_cols:
            if f'{sample_col}VSS32' in df.columns:
                # Count how many values are within threshold
                within_threshold = (abs(df[f'{sample_col}VSS32']) <= threshold).sum()
                total_count = len(df[f'{sample_col}VSS32'].dropna())
                percentage_within = (within_threshold / total_count * 100) if total_count > 0 else 0
                
                results.append({
                    'Sample': sample_col,
                    'Sample_Size': int(sample_col[1:]),
                    'Threshold_%': threshold,
                    'Within_Threshold_Count': within_threshold,
                    'Total_Count': total_count,
                    'Percentage_Within_Threshold': percentage_within
                })
    
    # Also analyze S32vsExpected
    for threshold in threshold_percentages:
        within_threshold = (abs(df['S32vsExpected']) <= threshold).sum()
        total_count = len(df['S32vsExpected'].dropna())
        percentage_within = (within_threshold / total_count * 100) if total_count > 0 else 0
        
        results.append({
            'Sample': 'S32vsExpected',
            'Sample_Size': 32,
            'Threshold_%': threshold,
            'Within_Threshold_Count': within_threshold,
            'Total_Count': total_count,
            'Percentage_Within_Threshold': percentage_within
        })
    
    threshold_df = pd.DataFrame(results)
    print(f"Threshold analysis completed for {len(sample_cols)} samples and S32vsExpected")
    
    return threshold_df


# =============================================================================
# PLOTTING FUNCTIONS
# =============================================================================

def create_ep_port_plots_with_legend(df):
    """Create plots for EP Portfolio data with legend information"""
    plots = {}
    legends = {}

    return_period_col = 'ReturnPeriod'
    vs_cols = [col for col in df.columns if col.endswith('VSS32') and col != 'S32vsExpected']
    cmap = get_cmap('tab20')  # Use matplotlib tab20 color map

    fig1, ax1 = plt.subplots(figsize=(7, 5))
    color_map = {}

    for i, col in enumerate(vs_cols):
        color = cmap(i % 20)
        hex_color = to_hex(color)
        color_map[col] = hex_color
        ax1.plot(df[return_period_col], df[col], label=col, color=color)

    ax1.set_xlabel('Return Period')
    ax1.set_ylabel('% Difference from S32')
    ax1.set_title('All Sample % Diffs vs S32')
    ax1.grid(True)
    ax1.set_xlim((0, df[return_period_col].max()))
    ax1.set_ylim((-10, 10))
    ax1.legend()

    buf1 = io.BytesIO()
    fig1.tight_layout()
    fig1.savefig(buf1, format='png')
    buf1.seek(0)
    plots['all_samples'] = buf1
    legends['all_samples'] = color_map
    plt.close(fig1)

    # Plot S24VSS32 if available
    if 'S24VSS32' in df.columns:
        fig2, ax2 = plt.subplots(figsize=(7, 5))
        ax2.plot(df[return_period_col], df['S24VSS32'], color='blue', label='S24VSS32')
        ax2.set_ylabel('% Difference from S32')
        ax2.set_xlabel('Return Period')
        ax2.set_title('S24 vs S32 % Difference')
        ax2.grid(True)
        ax2.legend()
        ax2.set_ylim((-10, 10))
        ax2.set_xlim((0, df[return_period_col].max()))

        buf2 = io.BytesIO()
        fig2.tight_layout()
        fig2.savefig(buf2, format='png')
        buf2.seek(0)
        plots['s24'] = buf2
        legends['s24'] = {'S24VSS32': '#0000FF'}  # blue
        plt.close(fig2)

    return plots, legends


def insert_plots_with_legend(worksheet, plots, legends):
    """Insert plots and legends into Excel worksheet"""
    row = 0
    for key, buf in plots.items():
        # Insert the plot image
        image_data = buf.read()
        worksheet.insert_image(row, 0, f"{key}.png", {'image_data': io.BytesIO(image_data)})

        # Insert the legend table beside it
        legend_map = legends.get(key, {})
        worksheet.write(row, 8, "Legend:")
        worksheet.write(row + 1, 8, "Line Name")
        worksheet.write(row + 1, 9, "Color (Hex)")

        for i, (line_name, hex_color) in enumerate(legend_map.items()):
            worksheet.write(row + 2 + i, 8, line_name)
            worksheet.write(row + 2 + i, 9, hex_color)

        row += 35  # Space between plots


# =============================================================================
# MAIN EXECUTION
# =============================================================================

def main():
    """Main execution function"""
    
    # Configuration
    results_path = r'C:\Users\Ashley.Yang\Downloads\DK_RES_GR_GU\Results'
    output_base_path = r'C:\Users\Ashley.Yang\Downloads\DK_RES_GR_GU'
    
    print("="*60)
    print("STARTING DATA AGGREGATION")
    print("="*60)
    
    # Step 1: Aggregate all data
    print("\n1. Processing EP Portfolio Data...")
    EP_GR = ep_port_aggregating_files(results_path, "GR")
    EP_GU = ep_port_aggregating_files(results_path, "GU")
    
    print("\n2. Processing Stats Portfolio Data...")
    STAT_GR = stat_port_aggregating_files(results_path, "GR")
    STAT_GU = stat_port_aggregating_files(results_path, "GU")
    
    print("\n3. Calculating Threshold Analysis...")
    # Calculate thresholds for each dataset
    thresholds_ep_gr = calculate_thresholds(EP_GR)
    thresholds_ep_gu = calculate_thresholds(EP_GU)
    thresholds_stat_gr = calculate_thresholds(STAT_GR)
    thresholds_stat_gu = calculate_thresholds(STAT_GU)
    
    print("\n" + "="*60)
    print("SAVING DATA TO EXCEL")
    print("="*60)
    
    # Step 2: Save basic aggregation results
    basic_excel_path = os.path.join(output_base_path, 'DK_RES_GR_GU_Aggregation.xlsx')
    print(f"\n4. Saving basic data to: {basic_excel_path}")
    
    with pd.ExcelWriter(basic_excel_path) as writer:
        EP_GR.to_excel(writer, sheet_name="EP_PORT_GR", index=False)
        STAT_GR.to_excel(writer, sheet_name="STAT_PORT_GR", index=False)
        EP_GU.to_excel(writer, sheet_name="EP_PORT_GU", index=False) 
        STAT_GU.to_excel(writer, sheet_name="STAT_PORT_GU", index=False)
        
        # Add threshold analysis sheets
        thresholds_ep_gr.to_excel(writer, sheet_name="Thresholds_EP_GR", index=False)
        thresholds_ep_gu.to_excel(writer, sheet_name="Thresholds_EP_GU", index=False)
        thresholds_stat_gr.to_excel(writer, sheet_name="Thresholds_STAT_GR", index=False)
        thresholds_stat_gu.to_excel(writer, sheet_name="Thresholds_STAT_GU", index=False)
    
    # Step 3: Create enhanced Excel with plots
    plots_excel_path = os.path.join(output_base_path, 'DK_RES_GR_GU_Aggregation_with_plots.xlsx')
    print(f"\n5. Creating enhanced Excel with plots: {plots_excel_path}")
    
    with pd.ExcelWriter(plots_excel_path, engine='xlsxwriter') as writer:
        # Write dataframes
        EP_GR.to_excel(writer, sheet_name="EP_PORT_GR", index=False)
        STAT_GR.to_excel(writer, sheet_name="STAT_PORT_GR", index=False)
        EP_GU.to_excel(writer, sheet_name="EP_PORT_GU", index=False)
        STAT_GU.to_excel(writer, sheet_name="STAT_PORT_GU", index=False)
        
        # Add threshold analysis sheets
        thresholds_ep_gr.to_excel(writer, sheet_name="Thresholds_EP_GR", index=False)
        thresholds_ep_gu.to_excel(writer, sheet_name="Thresholds_EP_GU", index=False)
        thresholds_stat_gr.to_excel(writer, sheet_name="Thresholds_STAT_GR", index=False)
        thresholds_stat_gu.to_excel(writer, sheet_name="Thresholds_STAT_GU", index=False)

        workbook = writer.book

        # Generate and insert plots for EP data only (since plots are for EP curves)
        if not EP_GR.empty:
            print("   - Creating EP GR plots...")
            plots_gr, legends_gr = create_ep_port_plots_with_legend(EP_GR)
            worksheet_gr = workbook.add_worksheet("EP_GR_Plots")
            writer.sheets["EP_GR_Plots"] = worksheet_gr
            insert_plots_with_legend(worksheet_gr, plots_gr, legends_gr)

        if not EP_GU.empty:
            print("   - Creating EP GU plots...")
            plots_gu, legends_gu = create_ep_port_plots_with_legend(EP_GU)
            worksheet_gu = workbook.add_worksheet("EP_GU_Plots")
            writer.sheets["EP_GU_Plots"] = worksheet_gu
            insert_plots_with_legend(worksheet_gu, plots_gu, legends_gu)
    
    print("\n" + "="*60)
    print("SUMMARY")
    print("="*60)
    print(f"✓ EP GR data: {len(EP_GR)} rows")
    print(f"✓ EP GU data: {len(EP_GU)} rows")
    print(f"✓ STAT GR data: {len(STAT_GR)} rows")
    print(f"✓ STAT GU data: {len(STAT_GU)} rows")
    print(f"✓ Threshold analysis completed for all datasets")
    print(f"✓ Basic Excel saved: {basic_excel_path}")
    print(f"✓ Enhanced Excel with plots saved: {plots_excel_path}")
    print("\nProcessing completed successfully!")


if __name__ == "__main__":
    main()
    """
    Aggregates EP portfolio files from Results directory.
    Expected folder and sample folders are all at the same level in Results directory.
    
    Args:
        results_base_path: Path to Results directory containing all folders
        loss_type: "GU" or "GR"
    """
    import pandas as pd
    import os
    import re
    
    print(f"Processing EP Portfolio data for Loss Type: {loss_type}")
    print(f"Results Directory: {results_base_path}")
    
    df = pd.DataFrame()
    sample_sizes = []
    
    # Validate loss_type
    if loss_type not in ['GU', 'GR']:
        print(f"Warning: Unexpected loss_type '{loss_type}'. Expected 'GU' or 'GR'")
        return pd.DataFrame()
    
    if not os.path.exists(results_base_path):
        print(f"Results directory not found: {results_base_path}")
        return pd.DataFrame()
    
    result_folders = [d for d in os.listdir(results_base_path) 
                     if os.path.isdir(os.path.join(results_base_path, d))]
    
    print(f"Found {len(result_folders)} folders")
    
    # Step 1: Find and load the Expected folder
    expected_found = False
    for folder_name in result_folders:
        if "Expected" in folder_name:
            folder_path = os.path.join(results_base_path, folder_name)
            expected_file_path = os.path.join(folder_path, "EP", "Portfolio", loss_type, "EP100.parquet")
            
            if os.path.exists(expected_file_path):
                df = pd.read_parquet(expected_file_path)
                df['Expected'] = df['Loss']
                df['LossType'] = loss_type
                expected_found = True
                print(f"Loaded Expected data from folder: {folder_name}")
                break
    
    if not expected_found:
        print(f"No Expected folder found for {loss_type}")
        return pd.DataFrame()
    
    # Step 2: Process all sample folders
    processed_files = 0
    for folder_name in result_folders:
        if "Expected" not in folder_name:  # Skip the Expected folder
            folder_path = os.path.join(results_base_path, folder_name)
            sample_file_path = os.path.join(folder_path, "EP", "Portfolio", loss_type, "EP100.parquet")
            
            if os.path.exists(sample_file_path):
                try:
                    df_temp = pd.read_parquet(sample_file_path)
                    
                    # Extract sample size from folder name
                    sample_size = None
                    match = re.search(r'_S(\d+)_', folder_name)
                    if match:
                        sample_size = int(match.group(1))
                    else:
                        # Fallback: use processed count + 1
                        sample_size = processed_files + 1
                    
                    # Add sample column
                    column_name = f'S{sample_size}'
                    df[column_name] = df_temp['Loss']
                    sample_sizes.append(sample_size)
                    processed_files += 1
                    print(f"Added {loss_type} sample from {folder_name}: {column_name}")
                    
                except Exception as e:
                    print(f"Error processing {folder_name}: {str(e)}")
                    continue
    
    sample_sizes.sort()
    print(f"Processed {processed_files} sample folders")
    print(f"Sample sizes: {sample_sizes}")
    
    # Calculate differences vs S32
    for sample_size in sample_sizes:
        s_col = f'S{sample_size}'
        if sample_size != 32 and s_col in df.columns and 'S32' in df.columns:
            df[f'{s_col}VSS32'] = (df[s_col] - df['S32']) / df['S32'] * 100

    # Calculate S32 vs Expected (this is the key comparison)
    if 'S32' in df.columns and 'Expected' in df.columns:
        df['S32vsExpected'] = (df['S32'] - df['Expected']) / df['Expected'] * 100

    # Reorder columns
    base_cols = [col for col in df.columns if not col.startswith('S') or col == 'S32vsExpected']

    s_cols = sorted(
        [col for col in df.columns if col.startswith('S') and 'vs' not in col and col[1:].isdigit()],
        key=lambda x: int(x[1:])
    )

    vs_cols = sorted(
        [col for col in df.columns if 'VSS32' in col and col[1:col.find('V')].isdigit()],
        key=lambda x: int(x[1:x.find('V')])
    )

    if 'S32vsExpected' in base_cols:
        base_cols.remove('S32vsExpected')

    new_order = base_cols + s_cols + vs_cols + ['S32vsExpected']
    df = df[new_order]

    # Filter to only OEP data
    if 'EPType' in df.columns:
        df = df[df['EPType'] == 'OEP']

    return df


# Stats Portfolio Aggregation Function - Corrected Structure
def stat_port_aggregating_files(results_base_path, loss_type):
    """
    Aggregates Stats portfolio files from Results directory.
    Expected folder and sample folders are all at the same level in Results directory.
    Uses AAL (Average Annual Loss) instead of Loss.
    
    Args:
        results_base_path: Path to Results directory containing all folders
        loss_type: "GU" or "GR"
    """
    
    print(f"Processing Stats Portfolio data for Loss Type: {loss_type}")
    print(f"Results Directory: {results_base_path}")
    
    df = pd.DataFrame()
    sample_sizes = []
    
    # Validate loss_type
    if loss_type not in ['GU', 'GR']:
        print(f"Warning: Unexpected loss_type '{loss_type}'. Expected 'GU' or 'GR'")
        return pd.DataFrame()
    
    if not os.path.exists(results_base_path):
        print(f"Results directory not found: {results_base_path}")
        return pd.DataFrame()
    
    result_folders = [d for d in os.listdir(results_base_path) 
                     if os.path.isdir(os.path.join(results_base_path, d))]
    
    print(f"Found {len(result_folders)} folders")
    
    # Step 1: Find and load the Expected folder
    expected_found = False
    for folder_name in result_folders:
        if "Expected" in folder_name:
            folder_path = os.path.join(results_base_path, folder_name)
            expected_file_path = os.path.join(folder_path, "Stats", "Portfolio", loss_type, "Stats100.parquet")
            
            if os.path.exists(expected_file_path):
                df = pd.read_parquet(expected_file_path)
                df['Expected'] = df['AAL']  # Use AAL for stats instead of Loss
                df['LossType'] = loss_type
                expected_found = True
                print(f"Loaded Expected data from folder: {folder_name}")
                break
    
    if not expected_found:
        print(f"No Expected folder found for {loss_type}")
        return pd.DataFrame()
    
    # Step 2: Process all sample folders
    processed_files = 0
    for folder_name in result_folders:
        if "Expected" not in folder_name:  # Skip the Expected folder
            folder_path = os.path.join(results_base_path, folder_name)
            sample_file_path = os.path.join(folder_path, "Stats", "Portfolio", loss_type, "Stats100.parquet")
            
            if os.path.exists(sample_file_path):
                try:
                    df_temp = pd.read_parquet(sample_file_path)
                    
                    # Extract sample size from folder name
                    sample_size = None
                    match = re.search(r'_S(\d+)_', folder_name)
                    if match:
                        sample_size = int(match.group(1))
                    else:
                        # Fallback: use processed count + 1
                        sample_size = processed_files + 1
                    
                    # Add sample column using AAL
                    column_name = f'S{sample_size}'
                    df[column_name] = df_temp['AAL']  # Use AAL for stats instead of Loss
                    sample_sizes.append(sample_size)
                    processed_files += 1
                    print(f"Added {loss_type} sample from {folder_name}: {column_name}")
                    
                except Exception as e:
                    print(f"Error processing {folder_name}: {str(e)}")
                    continue
    
    sample_sizes.sort()
    print(f"Processed {processed_files} sample folders")
    print(f"Sample sizes: {sample_sizes}")
    
    # Calculate differences vs S32
    for sample_size in sample_sizes:
        s_col = f'S{sample_size}'
        if sample_size != 32 and s_col in df.columns and 'S32' in df.columns:
            df[f'{s_col}VSS32'] = (df[s_col] - df['S32']) / df['S32'] * 100

    # Calculate S32 vs Expected (this is the key comparison)
    if 'S32' in df.columns and 'Expected' in df.columns:
        df['S32vsExpected'] = (df['S32'] - df['Expected']) / df['Expected'] * 100

    # Reorder columns (same as original stats function)
    base_cols = [col for col in df.columns if not col.startswith('S') or col == 'S32vsExpected']

    s_cols = sorted(
        [col for col in df.columns if col.startswith('S') and 'vs' not in col and col[1:].isdigit()],
        key=lambda x: int(x[1:])
    )

    vs_cols = sorted(
        [col for col in df.columns if 'VSS32' in col and col[1:col.find('V')].isdigit()],
        key=lambda x: int(x[1:x.find('V')])
    )

    if 'S32vsExpected' in base_cols:
        base_cols.remove('S32vsExpected')

    new_order = base_cols + s_cols + vs_cols
    if 'S32vsExpected' in df.columns:
        new_order += ['S32vsExpected']
    df = df[new_order]

    return df

EP_GR = ep_port_aggregating_files(r'C:\Users\Ashley.Yang\Downloads\DK_RES_GR_GU\Results', "GR")
EP_GU = ep_port_aggregating_files(r'C:\Users\Ashley.Yang\Downloads\DK_RES_GR_GU\Results', "GU")
STAT_GR = stat_port_aggregating_files(r'C:\Users\Ashley.Yang\Downloads\DK_RES_GR_GU\Results', "GR")
STAT_GU=stat_port_aggregating_files(r'C:\Users\Ashley.Yang\Downloads\DK_RES_GR_GU\Results', "GU")
#save to excel sheet

with pd.ExcelWriter(r'C:\Users\Ashley.Yang\Downloads\DK_RES_GR_GU\DK_RES_GR_GU_Aggregation.xlsx') as writer:
    EP_GR.to_excel(writer, sheet_name="EP_PORT_GR", index=False)
    STAT_GR.to_excel(writer, sheet_name = "STAT_PORT_GR", index=False)
    EP_GU.to_excel(writer, sheet_name = "EP_PORT_GU", index=False) 
    STAT_GU.to_excel(writer, sheet_name = "STAT_PORT_GU", index=False)


# Set Excel output path
excel_path = r'C:\Users\Ashley.Yang\Downloads\DK_RES_GR_GU\DK_RES_GR_GU_Aggregation_plots.xlsx'

# Create Excel writer with xlsxwriter engine
with pd.ExcelWriter(excel_path, engine='xlsxwriter') as writer:
    # Write dataframes
    EP_GR.to_excel(writer, sheet_name="EP_PORT_GR", index=False)
    STAT_GR.to_excel(writer, sheet_name="STAT_PORT_GR", index=False)
    EP_GU.to_excel(writer, sheet_name="EP_PORT_GU", index=False)
    STAT_GU.to_excel(writer, sheet_name="STAT_PORT_GU", index=False)

    workbook = writer.book

    # Generate plots again (with legend extraction)
    def create_ep_port_plots_with_legend(df):
        plots = {}
        legends = {}

        return_period_col = 'ReturnPeriod'
        vs_cols = [col for col in df.columns if col.endswith('VSS32') and col != 'S32vsExpected']
        cmap = get_cmap('tab20')  # Use matplotlib tab20 color map

        fig1, ax1 = plt.subplots(figsize=(7, 5))
        color_map = {}

        for i, col in enumerate(vs_cols):
            color = cmap(i % 20)
            hex_color = to_hex(color)
            color_map[col] = hex_color
            ax1.plot(df[return_period_col],df[col], label=col, color=color)

        ax1.set_xlabel('Return Period')
        ax1.set_ylabel('% Difference from S32')
        ax1.set_title('All Sample % Diffs vs S32')
        ax1.grid(True)
        ax1.set_xlim((0, df[return_period_col].max()))
        ax1.set_ylim((-10,10))
        ax1.legend()

        buf1 = io.BytesIO()
        fig1.tight_layout()
        fig1.savefig(buf1, format='png')
        buf1.seek(0)
        plots['all_samples'] = buf1
        legends['all_samples'] = color_map
        plt.close(fig1)

        # Plot S24VSS32 if available
        if 'S24VSS32' in df.columns:
            fig2, ax2 = plt.subplots(figsize=(7, 5))
            ax2.plot( df[return_period_col], df['S24VSS32'], color='blue', label='S24VSS32')
            ax2.set_ylabel('% Difference from S32')
            ax2.set_xlabel('Return Period')
            ax2.set_title('S24 vs S32 % Difference')
            ax2.grid(True)
            ax2.legend()
            ax2.set_ylim((-10, 10))
            ax2.set_xlim((0, df[return_period_col].max()))

            buf2 = io.BytesIO()
            fig2.tight_layout()
            fig2.savefig(buf2, format='png')
            buf2.seek(0)
            plots['s24'] = buf2
            legends['s24'] = {'S24VSS32': '#0000FF'}  # blue
            plt.close(fig2)

        return plots, legends

    def insert_plots_with_legend(worksheet, plots, legends):
        row = 0
        for key, buf in plots.items():
            # Insert the plot image
            image_data = buf.read()
            worksheet.insert_image(row, 0, f"{key}.png", {'image_data': io.BytesIO(image_data)})

            # Insert the legend table beside it
            legend_map = legends.get(key, {})
            worksheet.write(row, 8, "Legend:")
            worksheet.write(row + 1, 8, "Line Name")
            worksheet.write(row + 1, 9, "Color (Hex)")

            for i, (line_name, hex_color) in enumerate(legend_map.items()):
                worksheet.write(row + 2 + i, 8, line_name)
                worksheet.write(row + 2 + i, 9, hex_color)

            row += 35  # Space between plots

    # EP_GR
    plots_gr, legends_gr = create_ep_port_plots_with_legend(EP_GR)
    worksheet_gr = workbook.add_worksheet("EP_GR_Plots")
    writer.sheets["EP_GR_Plots"] = worksheet_gr
    insert_plots_with_legend(worksheet_gr, plots_gr, legends_gr)

    # EP_GU
    plots_gu, legends_gu = create_ep_port_plots_with_legend(EP_GU)
    worksheet_gu = workbook.add_worksheet("EP_GU_Plots")
    writer.sheets["EP_GU_Plots"] = worksheet_gu
    insert_plots_with_legend(worksheet_gu, plots_gu, legends_gu)
