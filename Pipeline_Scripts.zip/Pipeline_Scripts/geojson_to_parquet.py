import pandas as pd
import json
from s2sphere import LatLng, CellId

S2_LEVEL = 10

def compute_s2_cell_id(lat, lon, level=S2_LEVEL):
    latlng = LatLng.from_degrees(lat, lon)
    return int(CellId.from_lat_lng(latlng).parent(level).id())

def geojson_to_partitioned_parquet(geojson_path, output_dir):
    with open(geojson_path, 'r') as f:
        geojson = json.load(f)

    records = []
    for feature in geojson['features']:
        props = feature['properties']
        lat, lon = props['LATITUDE'], props['LONGITUDE']
        s2_id = compute_s2_cell_id(lat, lon)

        records.append({
            'location_id': props['GDMID'],
            'name': props['NAME'],
            'code': props['CODE'],
            'lat': lat,
            'lon': lon,
            'id': props['id'],
            's2_cell_id': s2_id
        })

    df = pd.DataFrame(records)

    print(f"Saving {len(df)} points partitioned by s2_cell_id...")
    df.to_parquet(output_dir, partition_cols=["s2_cell_id"], index=False)
    print("Done!")

# Run it
geojson_to_partitioned_parquet(
    geojson_path="geojson/original.geojson",
    output_dir="data/points_partitioned"
)
