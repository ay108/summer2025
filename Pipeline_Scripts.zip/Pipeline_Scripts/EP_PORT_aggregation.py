import os
import pandas as pd
import matplotlib.pyplot as plt

def aggregating_files(portfolio_number, expected_id, number):
    port1 = {
    206072:1, 
    206076:5, 
    206077:10, 
    206079:16, 
    206080:32
    }

    # port2 = {
    #     202856:1,
    #     202857:2,
    #     202870:4,
    #     202885:5,
    #     202871:6,
    #     202886:10,
    #     202887:12 ,
    #     202890:16,
    #     203180:24,
    #     202906:32
    # }

    # port3 = {
    #         202909:1,
    #         202910:2,
    #         202911:4,
    #         202916:5,
    #         202914:6,
    #         202919:10,
    #         202920:12,
    #         202922:16,
    #         202926:24,
    #         202939:32
    # }

    # port4= {
    #     202948:1,
    #     202953:2,
    #     202993:4,
    #     202994:5,
    #     202995:6,
    #     202996:10,
    #     202997:12,
    #     202999:16,
    #     203001:24,
    #     205850:32
    # }


    #add however many portfolios you want here;
    # portfolios = {1: port1, 2: port2, 3: port3, 4: port4}
    # for now, we are only using one portfolio
    portfolios = {1: port1}
    portfolio = portfolios[number]

    df = pd.DataFrame()

    #put where the file is here (the EP PORTFOLIO data)
    expected_file_path = rf'C:\Users\yanga3\Downloads\DK_RES_GC_0\{portfolio_number}\{expected_id}\EP\Portfolio\GU\EP100.parquet'

    if os.path.exists(expected_file_path):
        df = pd.read_parquet(expected_file_path)
        df['Expected'] = df['Loss']
    else:
        print(f"Expected file not found: {expected_file_path}")
        return pd.DataFrame()

    for job_id, sample_size in portfolio.items():
        # Construct the file path for each job ID
        #The structure is: 102 (ex. this is `portfolio_number`) / 202821 (ex. this is `job_id`) / EP/Portfolio/GU/EP100.parquet
        file_path = rf'C:\Users\yanga3\Downloads\DK_RES_GC_0\{portfolio_number}\{job_id}\EP\Portfolio\GU\EP100.parquet'
        if os.path.exists(file_path):
            df_temp = pd.read_parquet(file_path)
            #we want to uniquely identify the sample size column (ex. will appear as S1, S2,...)
            df[f'S{sample_size}'] = df_temp['Loss']
        else:
            print(f"Missing file for job ID {job_id}: {file_path}")

    # differences vs S32
    for sample_size in portfolio.values():
        s_col = f'S{sample_size}'
        if sample_size != 32 and s_col in df.columns and 'S32' in df.columns:
            df[f'{s_col}VSS32'] =  (df[s_col] - df['S32']) / df['S32'] * 100

    if 'S32' in df.columns and 'Expected' in df.columns:
        df['S32vsExpected'] = (df['S32'] - df['Expected']) / df['Expected'] * 100

    #reordering:
    #Basic information first, followed by raw values, then comparisons, and finally S32VSExpected at the end
    base_cols = [col for col in df.columns if not col.startswith('S') or col == 'S32vsExpected']

    s_cols = sorted(
        [col for col in df.columns if col.startswith('S') and 'vs' not in col and col[1:].isdigit()],
        key=lambda x: int(x[1:])
        #so it sorts based on the sample size; smallest to largest 
    )

    vs_cols = sorted(
        [col for col in df.columns if 'VSS32' in col and col[1:col.find('V')].isdigit()],
        key=lambda x: int(x[1:x.find('V')])
    )

    if 'S32vsExpected' in base_cols:
        base_cols.remove('S32vsExpected')

    new_order = base_cols + s_cols + vs_cols + ['S32vsExpected']
    df = df[new_order]

    #only keep the df rows that are "OEP" in EPType
    df = df[df['EPType'] == 'OEP']

    return df


df1 = aggregating_files(75, 201894, 1)
# df2 = aggregating_files(103, 203195, 2)
# df3 = aggregating_files(104, 203196, 3)
# df4 = aggregating_files(105, 203197, 4)

# #want to merge them into an excel file, separated by sheet per portfolio
with pd.ExcelWriter(r'C:\Users\yanga3\Downloads\DK_GC_0.xlsx') as writer:
    df1.to_excel(writer, sheet_name='75', index=False)
    # df2.to_excel(writer, sheet_name='103', index=False)
    # df3.to_excel(writer, sheet_name='104', index=False)
    # df4.to_excel(writer, sheet_name='105', index=False)

