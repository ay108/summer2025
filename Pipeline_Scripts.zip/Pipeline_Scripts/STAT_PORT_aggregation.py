import pandas as pd
import os
def stat_port_aggregating_files(portfolio_number, expected_id, number, loss_type):
    port1 = {
    206072:1, 
    206076:5, 
    206077:10, 
    206079:16, 
    206080:32
    }

    # port2 = {
    #     202856:1,
    #     202857:2,
    #     202870:4,
    #     202885:5,
    #     202871:6,
    #     202886:10,
    #     202887:12 ,
    #     202890:16,
    #     203180:24,
    #     202906:32
    # }

    # port3 = {
    #         202909:1,
    #         202910:2,
    #         202911:4,
    #         202916:5,
    #         202914:6,
    #         202919:10,
    #         202920:12,
    #         202922:16,
    #         202926:24,
    #         202939:32
    # }

    # port4= {
    #     202948:1,
    #     202953:2,
    #     202993:4,
    #     202994:5,
    #     202995:6,
    #     202996:10,
    #     202997:12,
    #     202999:16,
    #     203001:24,
    #     205850:32
    # }   
    portfolios = {1: port1}
    portfolio = portfolios[number]

    df = pd.DataFrame()

    # the expected file
    expected_file_path = rf'C:\Users\yanga3\Downloads\DK_RES_GC_0\{portfolio_number}\{expected_id}\Stats\Portfolio\{loss_type}\Stats100.parquet'

    if os.path.exists(expected_file_path):
        df = pd.read_parquet(expected_file_path)
        df['Expected'] = df['AAL']
    else:
        print(f"Expected file not found: {expected_file_path}")
        return pd.DataFrame()

    # add some job sample columns
    for job_id, sample_size in portfolio.items():
        file_path = rf'C:\Users\yanga3\Downloads\DK_RES_GC_0\{portfolio_number}\{job_id}\Stats\Portfolio\{loss_type}\Stats100.parquet'
        if os.path.exists(file_path):
            df_temp = pd.read_parquet(file_path)
            df[f'S{sample_size}'] = df_temp['AAL']
        else:
            print(f"Missing file for job ID {job_id}: {file_path}")

    # calculate differences and percentages vs S32
    for sample_size in portfolio.values():
        s_col = f'S{sample_size}'
        if sample_size != 32 and s_col in df.columns and 'S32' in df.columns:
            df[f'{s_col}VSS32'] = (df[s_col] - df['S32']) / df['S32'] * 100

    if 'S32' in df.columns and 'Expected' in df.columns:
        df['S32vsExpected'] = (df['S32'] - df['Expected']) / df['Expected'] * 100

    #reordering columns for excel; need to keep AAL for each sample, diff, then %age difference grouped together
    base_cols = [col for col in df.columns if not col.startswith('S') or col == 'S32vsExpected']

    s_cols = sorted(
        [col for col in df.columns if col.startswith('S') and 'vs' not in col and col[1:].isdigit()],
        key=lambda x: int(x[1:])
    )

    vs_cols = sorted(
        [col for col in df.columns if 'VSS32' in col and col[1:col.find('V')].isdigit()],
        key=lambda x: int(x[1:x.find('V')])
    )

    if 'S32vsExpected' in base_cols:
        base_cols.remove('S32vsExpected')

    new_order = base_cols + s_cols + vs_cols
    if 'S32vsExpected' in df.columns:
        new_order += ['S32vsExpected']
    df = df[new_order]

    return df
df1 = stat_port_aggregating_files(75, 201894, 1, "GU")
# df2 = stat_port_aggregating_files(103, 203195, 2, "GU")
# df3 = stat_port_aggregating_files(104, 203196, 3, "GU")
# df4 = stat_port_aggregating_files(105, 203197, 4, "GU")







