import pandas as pd
import json
import math
import numpy as np
from sklearn.neighbors import KDTree
import pickle
from collections import deque
import time
import sys
import matplotlib.pyplot as plt


# Load GeoJSON
def load_geojson_data(file_path=None):
    if file_path:
        with open(file_path, 'r') as f:
            return json.load(f)

def build_knn_graph(all_points, k=4):
    coords = np.array([[p['lat'], p['lon']] for p in all_points])
    ids = [p['location_id'] for p in all_points]
    
    start_build = time.time()
    tree = KDTree(coords, leaf_size=30, metric='euclidean')
    build_duration = time.time() - start_build

    start_query = time.time()
    dists, indices = tree.query(coords, k=k+1)  # +1 to exclude self if needed
    query_duration = time.time() - start_query
    graph = {}

    for i, (distances, neighbors) in enumerate(zip(dists, indices)):
        center_id = ids[i]
        neighbor_ids = []
        
        for dist, neighbor_idx in zip(distances, neighbors):
            if ids[neighbor_idx] != center_id:
                neighbor_ids.append(ids[neighbor_idx])
        
        graph[center_id] = neighbor_ids

    return graph, build_duration, query_duration

def save_graph(graph, filepath):
    with open(filepath, 'wb') as f:
        pickle.dump(graph, f)

def load_graph(filepath):
    with open(filepath, 'rb') as f:
        return pickle.load(f)

def get_neighbors(graph, node_id):
    return graph.get(node_id, [])

def bfs_neighbors(graph, start_id, max_depth=2, max_nodes=None):
    visited = set([start_id])
    queue = deque([(start_id, 0)])
    result = []

    while queue:
        node, depth = queue.popleft()
        result.append(node)

        if max_nodes is not None and len(visited) >= max_nodes:
            break

        if depth < max_depth:
            neighbors = graph.get(node, [])
            for neighbor in neighbors:
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append((neighbor, depth + 1))
    return result
def visualize_geographic_graph(graph, all_points, max_nodes=2000, sample_edges=3000):
    """Visualize the graph using actual geographic coordinates"""
    
    # Create coordinate mapping
    coord_map = {}
    for point in all_points:
        coord_map[point['location_id']] = (point['lon'], point['lat'])
    
    # Get subset of nodes
    nodes = list(graph.keys())[:max_nodes]
    
    # Collect coordinates
    lons = [coord_map[node][0] for node in nodes if node in coord_map]
    lats = [coord_map[node][1] for node in nodes if node in coord_map]
    
    # Create the plot
    plt.figure(figsize=(15, 12))
    
    # Plot all points
    plt.scatter(lons, lats, c='red', s=20, alpha=0.7, zorder=2, label='Points')
    
    # Plot edges (sample to avoid overcrowding)
    edge_count = 0
    for node in nodes:
        if node in coord_map and edge_count < sample_edges:
            node_coords = coord_map[node]
            neighbors = graph[node]
            
            for neighbor in neighbors:
                if neighbor in coord_map and neighbor in nodes:
                    neighbor_coords = coord_map[neighbor]
                    
                    # Draw edge
                    plt.plot([node_coords[0], neighbor_coords[0]], 
                            [node_coords[1], neighbor_coords[1]], 
                            'b-', alpha=0.3, linewidth=0.5, zorder=1)
                    edge_count += 1
                    
                    if edge_count >= sample_edges:
                        break
    
    plt.xlabel('Longitude')
    plt.ylabel('Latitude')
    plt.title(f'Geographic k-NN Graph\n{len(nodes)} points, ~{edge_count} edges shown')
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.axis('equal')
    plt.tight_layout()
    plt.show()


# Main
geojson_data = load_geojson_data(r"C:\Users\yanga3\Downloads\test_shp.geojson")

all_points = [{
    'location_id': f['properties']['GDMID'],
    'lat': f['properties']['LATITUDE'],
    'lon': f['properties']['LONGITUDE']
} for f in geojson_data['features']]


# Build the KD-tree graph and time it
graph, build_time, query_time = build_knn_graph(all_points, k=4)
print(f"KDTree build time: {build_time:.6f} seconds")
print(f"KDTree total query time (all {len(all_points)} points): {query_time:.6f} seconds")
print(f"Average time per point during query: {query_time / len(all_points):.6f} seconds")


test_point_id = all_points[100]['location_id']
print(f"\nSample test point ID for neighbors: {test_point_id}")

# Print direct k-NN neighbors for the sample test point
direct_neighbors = graph.get(test_point_id, [])
print(f"Direct k-NN neighbors ({len(direct_neighbors)}): {direct_neighbors}")

# # BFS starting at the same test point with max_depth=2
# start_time = time.time()
# bfs_result = bfs_neighbors(graph, test_point_id, max_depth=2)
# bfs_duration = time.time() - start_time

# print(f"\nBFS traversal starting at node {test_point_id}:")
# print(f"Number of nodes reached within 2 hops: {len(bfs_result)}")
# print(f"BFS traversal time: {bfs_duration:.6f} seconds")

# max_print = 9
# print(f"\nFirst {max_print} BFS nodes and their neighbors:")
# for i, node_id in enumerate(bfs_result[:max_print], 1):
#     neighbors = graph.get(node_id, [])
#     print(f"{i}. Node ID: {node_id} — Neighbors ({len(neighbors)}): {neighbors}")

# Visualize using actual coordinates
visualize_geographic_graph(graph, all_points, max_nodes=2000, sample_edges=3000)