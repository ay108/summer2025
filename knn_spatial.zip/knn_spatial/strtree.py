import json
import random
import time
from shapely.geometry import shape
from shapely.strtree import STRtree

def load_geojson_data(file_path=None):
    if file_path:
        with open(file_path, 'r') as f:
            return json.load(f)
def build_touching_graph_strtree(geojson_data):
    features = geojson_data['features']

    geometries = []
    id_to_geom = {}
    geom_to_id = {}

    print(f"Processing {len(features)} features...")

    for i, f in enumerate(features):
        try:
            geom = shape(f['geometry'])
            geom_id = f['properties']['GDMID']

            if not geom.is_valid:
                print(f"Invalid geometry at index {i}, ID {geom_id}")
                geom = geom.buffer(0)

            geometries.append(geom)
            id_to_geom[geom_id] = geom
            geom_to_id[id(geom)] = geom_id  # Use id() here

        except Exception as e:
            print(f"Error processing feature {i}: {e}")
            continue

    # Build STRtree
    tree = STRtree(geometries)
    print("STRtree built successfully")

    touching_graph = {}
    start = time.time()

    for geom in geometries:
        geom_id = geom_to_id[id(geom)]  # Use id() here
        candidates = tree.query(geom)

        touching_ids = []
        for candidate in candidates:
            if candidate is geom:
                continue
            if not isinstance(candidate, type(geom)):
                print(f"Warning: candidate {candidate} is not a valid geometry")
                continue
            try:
                if geom.touches(candidate):
                    candidate_id = geom_to_id.get(id(candidate))  # Use id() here
                    if candidate_id:
                        touching_ids.append(candidate_id)
            except Exception as e:
                print(f"Error checking .touches() between {geom} and {candidate}: {e}")

        touching_graph[geom_id] = touching_ids

    duration = time.time() - start
    print(f"Processed {len(geometries)} polygons in {duration:.2f} seconds")

    return touching_graph, duration

# Execution
geojson_data = load_geojson_data(r"C:\Users\yanga3\Downloads\test_shp.geojson")

touching_graph, duration = build_touching_graph_strtree(geojson_data)

# Save the graph
with open(r"C:\Users\yanga3\Downloads\touching_graph_strtree.json", 'w') as f:
    json.dump(touching_graph, f)

print(f"Built polygon adjacency graph (STRtree) for {len(touching_graph)} features in {duration:.2f} seconds.")


# PRE-BUILT + LOADED QUERY TESTING
# Comment out everything above here if you're reusing the saved graph only

# Load from file
with open(r"C:\Users\yanga3\Downloads\touching_graph_strtree.json", 'r') as f:
    touching_graph = json.load(f)

polygon_ids = list(touching_graph.keys())

for i in range(5):  # Show 5 random examples
    random_polygon = random.choice(polygon_ids)
    neighbors = touching_graph[random_polygon]
    print(f"Polygon {random_polygon}: {len(neighbors)} neighbors -> {neighbors}")

# Time neighbor fetching
print(f"\nTiming neighbor fetching:")
start_time = time.time()
for _ in range(10000):
    random_polygon = random.choice(polygon_ids)
    neighbors = touching_graph[random_polygon]
fetch_time = time.time() - start_time

# Safe example print
if len(touching_graph) > 100:
    example_id = list(touching_graph.keys())[201]
else:
    example_id = list(touching_graph.keys())[0] if touching_graph else None

if example_id:
    print(f"\nPolygon {example_id} touches: {touching_graph[example_id]}")
    print(f"Number of touching neighbors: {len(touching_graph[example_id])}")
else:
    print("No polygons found in touching graph")

# Quick statistics
if touching_graph:
    touch_counts = [len(neighbors) for neighbors in touching_graph.values()]
    print(f"\nTouch statistics:")
    print(f"Average neighbors per polygon: {sum(touch_counts)/len(touch_counts):.2f}")
    print(f"Max neighbors: {max(touch_counts)}")
    print(f"Polygons with no neighbors: {touch_counts.count(0)}")
