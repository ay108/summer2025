"""
Spatial Adjacency Analysis using QuadTree Index

This module provides efficient spatial analysis for polygon datasets using QuadTree
spatial indexing to find touching/adjacent polygons and analyze neighborhood relationships.

Author:
 Ashley Yang
Created: 2025
Description: 
    - Loads GeoJSON polygon data and builds spatial adjacency graphs
    - Uses QuadTree spatial indexing for fast neighbor queries
    - Provides first-order and second-order neighborhood analysis
    - Optimized for large geographic datasets

Key Features:
    - QuadTree-based spatial indexing for O(log n) neighbor queries
    - Bounding box intersection for fast adjacency detection
    - First and second-order neighborhood analysis
    - Performance benchmarking and statistics
    - JSON serialization for pre-computed adjacency graphs
"""
import json
import random
from shapely.geometry import shape
import pyqtree
import time

def load_geojson_data(file_path=None):
    if file_path:
        with open(file_path, 'r') as f:
            return json.load(f)

def bboxes_touch(b1, b2):
    # b1 and b2 are (minx, miny, maxx, maxy)
    return (
        b1[2] >= b2[0] and b1[0] <= b2[2] and
        b1[3] >= b2[1] and b1[1] <= b2[3]
    )

def build_touching_graph_quadtree(geojson_data):
    features = geojson_data['features']

    id_to_bbox = {}
    ids = []

    # Collect bounding box extents to build global quadtree bounds
    minx = miny = float('inf')
    maxx = maxy = float('-inf')

    print(f"Processing {len(features)} features...")

    for f in features:
        try:
            geom_id = f['properties']['GDMID']
            coords = f['geometry']['coordinates'][0]

            xs = [pt[0] for pt in coords]
            ys = [pt[1] for pt in coords]
            bbox = (min(xs), min(ys), max(xs), max(ys))

            id_to_bbox[geom_id] = bbox
            ids.append(geom_id)

            minx = min(minx, bbox[0])
            miny = min(miny, bbox[1])
            maxx = max(maxx, bbox[2])
            maxy = max(maxy, bbox[3])

        except Exception as e:
            print(f"Error processing feature {f.get('properties', {}).get('GDMID', '?')}: {e}")
            continue

    print(f"Global bounding box: ({minx:.6f}, {miny:.6f}, {maxx:.6f}, {maxy:.6f})")

    # Add buffer
    buffer = max((maxx - minx), (maxy - miny)) * 0.01
    bbox = (minx - buffer, miny - buffer, maxx + buffer, maxy + buffer)

    print(f"Quadtree bounding box: ({bbox[0]:.6f}, {bbox[1]:.6f}, {bbox[2]:.6f}, {bbox[3]:.6f})")

    # Build Quadtree
    try:
        quadtree = pyqtree.Index(bbox=bbox)
    except Exception as e:
        print(f"Error creating quadtree: {e}")
        return {}, 0

    for geom_id, bounds in id_to_bbox.items():
        quadtree.insert(item=geom_id, bbox=bounds)

    touching_graph = {}
    start = time.time()

    for i, geom_id in enumerate(ids):
        bbox = id_to_bbox[geom_id]
        candidates = quadtree.intersect(bbox)
        neighbors = [
            cand_id for cand_id in candidates
            if cand_id != geom_id and bboxes_touch(bbox, id_to_bbox[cand_id])
        ]
        touching_graph[geom_id] = neighbors

        if (i + 1) % 100 == 0:
            print(f"Processed {i + 1}/{len(ids)}")

    duration = time.time() - start
    print(f"Built graph in {duration:.2f} seconds")

    return touching_graph, duration


def get_second_order_neighbors(touching_graph, polygon_id):
    first_order = set(touching_graph.get(polygon_id, []))
    second_order = set()

    for neighbor in first_order:
        second_order.update(touching_graph.get(neighbor, []))

    # Remove the original polygon and first-order neighbors
    second_order.discard(polygon_id)
    second_order -= first_order

    return list(second_order)

# execution
geojson_data = load_geojson_data(r"C:\Users\yanga3\Downloads\test_shp.geojson")

touching_graph, duration = build_touching_graph_quadtree(geojson_data)

#save the touching graph to a file
with open(r"C:\Users\yanga3\Downloads\touching_graph_quadtree.json", 'w') as f:
    json.dump(touching_graph, f)

print(f"Built polygon adjacency graph (quadtree) for {len(touching_graph)} features in {duration:.2f} seconds.")


# PRE_BUILT + LOADED QUERY TESTING
# TO test this, comment out everything above these comments :)
#  load in the touching graph from file
with open(r"C:\Users\yanga3\Downloads\touching_graph_quadtree.json", 'r') as f:
    touching_graph = json.load(f)

polygon_ids = list(touching_graph.keys())

    
for i in range(5):  # Show 5 random examples
    random_polygon = random.choice(polygon_ids)
    neighbors = touching_graph[random_polygon]
    print(f"Polygon {random_polygon}: {len(neighbors)} neighbors -> {neighbors}")


# Time neighbor fetching for 10,000 random queries
print(f"\nTiming neighbor fetching:")
start_time = time.time()
for _ in range(10000):
    random_polygon = random.choice(polygon_ids)
    neighbors = touching_graph[random_polygon]  # fetching!
fetch_time = time.time() - start_time

#  example print
if len(touching_graph) > 100:
    example_id = list(touching_graph.keys())[99]
else:
    example_id = list(touching_graph.keys())[0] if touching_graph else None

if example_id:
    print(f"\nPolygon {example_id} touches: {touching_graph[example_id]}")
    print(f"Number of touching neighbors: {len(touching_graph[example_id])}")
else:
    print("No polygons found in touching graph")


#get second order neighbors
polygon_id = '387306382'  
second_neighbors = get_second_order_neighbors(touching_graph, polygon_id)
print(f"Second-order neighbors of {polygon_id}: {second_neighbors}")


# Quick statistics
if touching_graph:
    touch_counts = [len(neighbors) for neighbors in touching_graph.values()]
    print(f"\nTouch statistics:")
    print(f"Average neighbors per polygon: {sum(touch_counts)/len(touch_counts):.2f}")
    print(f"Max neighbors: {max(touch_counts)}")
    print(f"Polygons with no neighbors: {touch_counts.count(0)}")

