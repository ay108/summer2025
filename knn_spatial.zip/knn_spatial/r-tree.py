import json
import random
import time
from shapely.geometry import shape
from rtree import index

def load_geojson_data(file_path=None):
    if file_path:
        with open(file_path, 'r') as f:
            return json.load(f)


def build_touching_graph_rtree(geojson_data):
    features = geojson_data['features']

    geometries = []
    ids = []

    print(f"Processing {len(features)} features...")

    # Prepare Rtree index
    rtree_idx = index.Index()

    # Collect geometries and insert bounding boxes in Rtree
    for i, f in enumerate(features):
        try:
            geom = shape(f['geometry'])
            geom_id = f['properties']['GDMID']

            if not geom.is_valid:
                print(f"Invalid geometry at index {i}, ID {geom_id} - attempting to fix")
                geom = geom.buffer(0)

            geometries.append(geom)
            ids.append(geom_id)

            minx, miny, maxx, maxy = geom.bounds
            rtree_idx.insert(i, (minx, miny, maxx, maxy))

        except Exception as e:
            print(f"Error processing feature {i}: {e}")
            continue

    touching_graph = {}
    start = time.time()

    # For each geometry, query overlapping bounding boxes from Rtree, then check touches
    for i, geom in enumerate(geometries):
        geom_id = ids[i]
        touching_ids = []

        minx, miny, maxx, maxy = geom.bounds
        candidate_indices = list(rtree_idx.intersection((minx, miny, maxx, maxy)))

        for idx in candidate_indices:
            if idx == i:
                continue  # skip self
            candidate_geom = geometries[idx]

            try:
                if geom.touches(candidate_geom):
                    touching_ids.append(ids[idx])
            except Exception as e:
                print(f"Error checking touches between {geom_id} and {ids[idx]}: {e}")

        touching_graph[geom_id] = touching_ids

    duration = time.time() - start
    print(f"Processed {len(geometries)} polygons in {duration:.2f} seconds")

    return touching_graph, duration

# Execution
geojson_data = load_geojson_data(r"C:\Users\yanga3\Downloads\test_shp.geojson")

touching_graph, duration = build_touching_graph_rtree(geojson_data)

# Save the graph
with open(r"C:\Users\yanga3\Downloads\touching_graph_rtree.json", 'w') as f:
    json.dump(touching_graph, f)

print(f"Built polygon adjacency graph (Rtree) for {len(touching_graph)} features in {duration:.2f} seconds.")


# PRE-BUILT + LOADED QUERY TESTING
# Comment out everything above here if you're reusing the saved graph only

with open(r"C:\Users\yanga3\Downloads\touching_graph_rtree.json", 'r') as f:
    touching_graph = json.load(f)

polygon_ids = list(touching_graph.keys())

for i in range(5):  # Show 5 random examples
    random_polygon = random.choice(polygon_ids)
    neighbors = touching_graph[random_polygon]
    print(f"Polygon {random_polygon}: {len(neighbors)} neighbors -> {neighbors}")


if len(touching_graph) > 100:
    example_id = list(touching_graph.keys())[100]
else:
    example_id = list(touching_graph.keys())[0] if touching_graph else None

if example_id:
    print(f"\nPolygon {example_id} touches: {touching_graph[example_id]}")
    print(f"Number of touching neighbors: {len(touching_graph[example_id])}")
else:
    print("No polygons found in touching graph")

# Quick statistics
if touching_graph:
    touch_counts = [len(neighbors) for neighbors in touching_graph.values()]
    print(f"\nTouch statistics:")
    print(f"Average neighbors per polygon: {sum(touch_counts)/len(touch_counts):.2f}")
    print(f"Max neighbors: {max(touch_counts)}")
    print(f"Polygons with no neighbors: {touch_counts.count(0)}")
