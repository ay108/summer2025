
"""
K-Nearest Neighbors Search using QuadTree Spatial Indexing

This module implements efficient K-Nearest Neighbors (KNN) search algorithms using
QuadTree data structures with spatial pruning optimizations for geographic data.

Author: Ashley Yang
Description:
    - Custom QuadTree implementation with spatial subdivision
    - Heap-based KNN search with distance prioritization
    - Spatial pruning optimization 
Key Features:
    - O(log n) KNN search with spatial pruning (vs O(n) brute force)
    - Max-heap implementation for efficient k-nearest maintenance
"""
import random
import math
import heapq
import json
import time
import pyqtree

MAX_POINTS = 4  # Max points per QuadTree node before subdivision

# Point class
class Point:
    def __init__(self, x, y, data=None):
        self.x = x
        self.y = y
        self.data = data  # Store additional data (like polygon ID, properties)

# Rectangle boundary class
class Rect:
    def __init__(self, x, y, hw, hh):
        self.x = x
        self.y = y
        self.hw = hw
        self.hh = hh

    def contains(self, point):
        return (self.x - self.hw <= point.x <= self.x + self.hw and
                self.y - self.hh <= point.y <= self.y + self.hh)

    def intersects(self, other):
        return not (self.x + self.hw < other.x - other.hw or
                    self.x - self.hw > other.x + other.hw or
                    self.y + self.hh < other.y - other.hh or
                    self.y - self.hh > other.y + other.hh)

# QuadTree node class
class QuadTree:
    def __init__(self, boundary):
        self.boundary = boundary
        self.points = []
        self.count = 0
        self.NW = self.NE = self.SW = self.SE = None

    def subdivide(self):
        x, y, hw, hh = self.boundary.x, self.boundary.y, self.boundary.hw / 2, self.boundary.hh / 2
        self.NW = QuadTree(Rect(x - hw, y - hh, hw, hh))
        self.NE = QuadTree(Rect(x + hw, y - hh, hw, hh))
        self.SW = QuadTree(Rect(x - hw, y + hh, hw, hh))
        self.SE = QuadTree(Rect(x + hw, y + hh, hw, hh))

    def insert(self, point):
        if not self.boundary.contains(point):
            return False

        if self.count < MAX_POINTS:
            self.points.append(point)
            self.count += 1
            return True

        if self.NW is None:
            self.subdivide()

        return (self.NW.insert(point) or self.NE.insert(point) or
                self.SW.insert(point) or self.SE.insert(point))

# Distance function
def distance(a, b):
    return math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2)

# KNN Search using max-heap (OPTION 2 - HEAP-BASED)
def knn_search_heap(qt, target, heap, k):
    """Efficient KNN search using max-heap to maintain k nearest neighbors"""
    if qt is None:
        return

    # Check all points in current node
    for p in qt.points:
        dist = distance(p, target)
        
        if len(heap) < k:
            # Heap not full, add point
            heapq.heappush(heap, (-dist, p))  # Negative distance for max-heap
        elif dist < -heap[0][0]:  # If closer than farthest in heap
            # Replace farthest neighbor with this closer one
            heapq.heapreplace(heap, (-dist, p))

    # Recursively search child nodes
    if qt.NW is not None:
        knn_search_heap(qt.NW, target, heap, k)
        knn_search_heap(qt.NE, target, heap, k)
        knn_search_heap(qt.SW, target, heap, k)
        knn_search_heap(qt.SE, target, heap, k)

# Optimized KNN with spatial pruning
def knn_search_optimized(qt, target, heap, k):
    """KNN search with spatial pruning - only search nodes that could contain closer points"""
    if qt is None:
        return

    # Calculate minimum possible distance from target to this node's boundary
    def min_distance_to_rect(point, rect):
        dx = max(0, max(rect.x - rect.hw - point.x, point.x - (rect.x + rect.hw)))
        dy = max(0, max(rect.y - rect.hh - point.y, point.y - (rect.y + rect.hh)))
        return math.sqrt(dx * dx + dy * dy)

    # If heap is full and this node can't possibly contain closer points, prune
    if len(heap) == k:
        min_possible_dist = min_distance_to_rect(target, qt.boundary)
        if min_possible_dist >= -heap[0][0]:  # heap[0][0] is negative max distance
            return

    # Check all points in current node
    for p in qt.points:
        dist = distance(p, target)
        
        if len(heap) < k:
            heapq.heappush(heap, (-dist, p))
        elif dist < -heap[0][0]:
            heapq.heapreplace(heap, (-dist, p))

    # Recursively search child nodes (with pruning)
    if qt.NW is not None:
        knn_search_optimized(qt.NW, target, heap, k)
        knn_search_optimized(qt.NE, target, heap, k)
        knn_search_optimized(qt.SW, target, heap, k)
        knn_search_optimized(qt.SE, target, heap, k)

# GeoJSON Integration Functions
def load_geojson_data(file_path):
    """Load GeoJSON data from file"""
    with open(file_path, 'r') as f:
        return json.load(f)

def get_polygon_centroid(coordinates):
    """Calculate centroid of polygon from coordinates"""
    outer_ring = coordinates[0]
    xs = [pt[0] for pt in outer_ring[:-1]]  # Exclude last point (same as first)
    ys = [pt[1] for pt in outer_ring[:-1]]
    
    centroid_x = sum(xs) / len(xs)
    centroid_y = sum(ys) / len(ys)
    return centroid_x, centroid_y

def build_quadtree_from_geojson(geojson_file_path):
    """Build QuadTree from GeoJSON file using polygon centroids"""
    print(f"Loading GeoJSON file: {geojson_file_path}")
    geojson_data = load_geojson_data(geojson_file_path)
    features = geojson_data['features']
    
    print(f"Processing {len(features)} features...")
    
    # Find bounds for QuadTree
    min_x = min_y = float('inf')
    max_x = max_y = float('-inf')
    
    centroids = []
    
    for feature in features:
        try:
            geom_id = feature['properties']['GDMID']
            coords = feature['geometry']['coordinates']
            cx, cy = get_polygon_centroid(coords)
            
            centroids.append((cx, cy, geom_id, feature['properties']))
            
            min_x = min(min_x, cx)
            max_x = max(max_x, cx)
            min_y = min(min_y, cy)
            max_y = max(max_y, cy)
            
        except Exception as e:
            print(f"Error processing feature: {e}")
            continue
    
    # Create QuadTree boundary with some padding
    center_x = (min_x + max_x) / 2
    center_y = (min_y + max_y) / 2
    half_width = (max_x - min_x) / 2 * 1.1  # 10% padding
    half_height = (max_y - min_y) / 2 * 1.1
    
    boundary = Rect(center_x, center_y, half_width, half_height)
    qt = QuadTree(boundary)
    
    # Insert all points
    id_to_point = {}
    for cx, cy, geom_id, properties in centroids:
        point = Point(cx, cy, {'id': geom_id, 'properties': properties})
        qt.insert(point)
        id_to_point[geom_id] = point
    
    print(f"Built QuadTree with {len(centroids)} points")
    return qt, id_to_point

# Print the K nearest neighbors with details
def print_knn_detailed(heap, target):
    """Print KNN results with detailed information"""
    print(f"\nK Nearest Neighbors to target ({target.x:.6f}, {target.y:.6f}):")
    print("-" * 80)
    
    # Sort by distance (heap stores negative distances)
    sorted_neighbors = sorted(heap, key=lambda x: -x[0])
    
    for i, (neg_dist, point) in enumerate(sorted_neighbors):
        distance_val = -neg_dist
        geom_id = point.data['id'] if point.data else 'Unknown'
        name = point.data['properties'].get('NAME', 'Unknown') if point.data and 'properties' in point.data else 'Unknown'
        
        print(f"{i+1}. ID: {geom_id} | Name: {name}")
        print(f"   Location: ({point.x:.6f}, {point.y:.6f})")
        print(f"   Distance: {distance_val:.6f}")
        print()

# Benchmark function
def benchmark_knn_methods(qt, target, k=5, num_trials=1000):
    """Benchmark different KNN search methods"""
    print(f"\nBenchmarking KNN methods ({num_trials} trials, k={k}):")
    print("-" * 60)
    
    # Method 1: Basic heap search
    start_time = time.time()
    for _ in range(num_trials):
        heap = []
        knn_search_heap(qt, target, heap, k)
    basic_time = time.time() - start_time
    
    # Method 2: Optimized with spatial pruning
    start_time = time.time()
    for _ in range(num_trials):
        heap = []
        knn_search_optimized(qt, target, heap, k)
    optimized_time = time.time() - start_time
    
    print(f"Basic heap search:     {basic_time:.4f} seconds ({basic_time/num_trials*1000:.4f} ms per query)")
    print(f"Optimized with pruning: {optimized_time:.4f} seconds ({optimized_time/num_trials*1000:.4f} ms per query)")
    print(f"Speedup: {basic_time/optimized_time:.2f}x")

# Main demo function
def main():
    print("=== QuadTree K-Nearest Neighbors Demo ===\n")
    
    # Option 1: Use GeoJSON file
    try:
        geojson_file = r"C:\Users\yanga3\Downloads\test_shp.geojson"
        qt, id_to_point = build_quadtree_from_geojson(geojson_file)
        
        # Use first polygon as target for demo
        target_id = list(id_to_point.keys())[0]
        target = id_to_point[target_id]
        print(f"Using polygon {target_id} as target")
        
    except Exception as e:
        print(f"Could not load GeoJSON file: {e}")
        print("Using random data instead...\n")
        
        # Option 2: Use random data (fallback)
        boundary = Rect(0.0, 0.0, 100.0, 100.0)
        qt = QuadTree(boundary)
        
        # Insert random points
        for i in range(1000):
            x = random.uniform(-100, 100)
            y = random.uniform(-100, 100)
            point = Point(x, y, {'id': f'point_{i}', 'properties': {'NAME': f'Point {i}'}})
            qt.insert(point)
        
        target = Point(10.0, 10.0, {'id': 'target', 'properties': {'NAME': 'Target Point'}})
    
    # Perform KNN search
    K = 5
    heap = []
    
    print(f"\nPerforming KNN search (k={K})...")
    start_time = time.time()
    knn_search_heap(qt, target, heap, K)
    search_time = time.time() - start_time
    
    print(f"Search completed in {search_time*1000:.4f} ms")
    
    # Display results
    print_knn_detailed(heap, target)
    
    # Benchmark different methods
    benchmark_knn_methods(qt, target, K, 1000)

if __name__ == "__main__":
    main()